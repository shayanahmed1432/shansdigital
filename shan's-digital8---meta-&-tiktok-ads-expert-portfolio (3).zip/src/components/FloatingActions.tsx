import { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export default function FloatingActions() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      setShowScrollTop(window.scrollY > 350);
    };
    window.addEventListener('scroll', checkScroll, { passive: true });
    return () => window.removeEventListener('scroll', checkScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!showScrollTop) return null;

  return (
    <div className="fixed bottom-[9rem] lg:bottom-28 right-4 sm:right-7 z-30 pointer-events-auto">
      {/* Scroll to Top button */}
      <button
        onClick={scrollToTop}
        aria-label="Scroll to top"
        className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700/80 shadow-lg flex items-center justify-center transition-all duration-200 transform hover:-translate-y-0.5 active:scale-95 backdrop-blur-sm"
      >
        <ArrowUp className="w-4 h-4 text-orange-400" />
      </button>
    </div>
  );
}
