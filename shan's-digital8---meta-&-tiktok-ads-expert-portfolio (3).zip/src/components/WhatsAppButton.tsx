import React from "react";
import "./WhatsAppButton.css";

export default function WhatsAppButton() {
  const phoneNumber = "923332327001";

  const message = encodeURIComponent(
    "Hi! I want to know more about your digital marketing services."
  );

  const whatsappURL = `https://wa.me/${phoneNumber}?text=${message}`;

  return (
    <a
      href={whatsappURL}
      className="whatsapp-float"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
    >
      <span className="whatsapp-pulse"></span>

      <span className="whatsapp-icon">
        <svg viewBox="0 0 32 32" aria-hidden="true">
          <path
            fill="currentColor"
            d="M16 3C8.8 3 3 8.7 3 15.8c0 2.5.7 4.9 2 7L3.5 29l6.4-1.7a13 13 0 0 0 6.1 1.5c7.2 0 13-5.8 13-13S23.2 3 16 3Zm0 23.5c-2 0-4-.5-5.7-1.6l-.4-.2-3.8 1 1-3.7-.3-.5a10.5 10.5 0 1 1 9.2 5Zm5.8-7.8c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.7l.5-.6c.2-.2.2-.4.3-.6.1-.2 0-.5 0-.6-.1-.2-.7-1.7-1-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.1 1.1-1.1 2.6s1.1 3 1.3 3.2c.1.2 2.2 3.4 5.4 4.7.8.4 1.5.6 2 .7.9.3 1.7.2 2.3.1.7-.1 1.8-.7 2.1-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.3-.6-.5Z"
          />
        </svg>
      </span>

      <span className="whatsapp-text">
        <strong>Chat with us</strong>
        <small>Let's grow your business</small>
      </span>

      <span className="whatsapp-arrow">↗</span>
    </a>
  );
}
