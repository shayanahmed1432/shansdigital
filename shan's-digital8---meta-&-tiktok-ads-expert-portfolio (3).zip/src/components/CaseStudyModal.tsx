import { CaseStudy } from '../types';
import { X, CheckCircle2, TrendingUp, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

interface CaseStudyModalProps {
  study: CaseStudy | null;
  onClose: () => void;
  onOpenAudit: () => void;
}

export default function CaseStudyModal({ study, onClose, onOpenAudit }: CaseStudyModalProps) {
  if (!study) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
              {study.platform}
            </span>
            <span aria-hidden="true" className="text-neutral-400">·</span>
            <span className="text-sm font-semibold text-neutral-900 dark:text-white">
              {study.client}
            </span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-lg text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="max-h-[75vh] overflow-y-auto p-6 sm:p-8 space-y-8">
          {/* Main Title */}
          <div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white leading-tight">
              {study.title}
            </h3>
            <div className="flex items-center gap-2 pt-2 text-xs text-neutral-500 dark:text-neutral-400">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Verified Ads Manager Export</span>
              <span aria-hidden="true">·</span>
              <span>Timeline: {study.timeline}</span>
            </div>
          </div>

          {/* Screenshot Showcase */}
          <div className="rounded-xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-950">
            <img
              src={study.image}
              alt={study.title}
              className="w-full h-auto object-contain max-h-[500px] mx-auto"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-900/50">
              <div className="text-xs text-orange-700 dark:text-orange-400 font-medium">Hero Return</div>
              <div className="text-3xl font-extrabold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                {study.heroMetric}
              </div>
              <div className="text-[11px] text-orange-700/80 dark:text-orange-400/80">{study.heroMetricLabel}</div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-100 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
              <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">Total Spend</div>
              <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                {study.results.spend}
              </div>
              <div className="text-[11px] text-neutral-500">Tracked in currency</div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-100 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
              <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">Total Value Generated</div>
              <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                {study.results.revenue}
              </div>
              <div className="text-[11px] text-neutral-500">Gross attributed</div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-100 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
              <div className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">Acquisition Cost</div>
              <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                {study.results.cpa}
              </div>
              <div className="text-[11px] text-neutral-500">Per purchase / lead</div>
            </div>
          </div>

          {/* Deep Breakdown: The Challenge & The Solution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="space-y-3 p-5 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800">
              <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-900 dark:text-white flex items-center gap-2">
                <span>The Challenge Before Shan'S Digital8</span>
              </h4>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                {study.challenge}
              </p>
            </div>

            <div className="space-y-3 p-5 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-800">
              <h4 className="text-sm font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span>The Engineering Solution</span>
              </h4>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                {study.solution}
              </p>
            </div>
          </div>

          {/* Tactical Execution Highlights */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-neutral-900 dark:text-white">
              Tactical Execution Framework
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {study.keyTactics.map((tactic, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-3.5 rounded-lg bg-neutral-100/70 dark:bg-neutral-800/50 border border-neutral-200 dark:border-neutral-800 text-sm text-neutral-700 dark:text-neutral-300"
                >
                  <CheckCircle2 className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                  <span>{tactic}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer with Direct Conversion Action */}
        <div className="p-6 bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-neutral-500 text-center sm:text-left">
            Have a similar product or offer? Let us audit your account for free.
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-800 rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenAudit();
              }}
              className="w-full sm:w-auto px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 rounded-lg shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>Apply Strategy to My Ads</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
