import { useState } from 'react';
import { Calculator, ArrowRight, TrendingUp, Sparkles, MessageCircle, Globe2 } from 'lucide-react';
import { SUPPORTED_MARKETS, MarketConfig, formatCurrencyAmount } from '../data/marketData';

interface RoasCalculatorProps {
  onOpenAuditWithSpend: (spend: number) => void;
}

export default function RoasCalculator({ onOpenAuditWithSpend }: RoasCalculatorProps) {
  const [selectedMarket, setSelectedMarket] = useState<MarketConfig>(SUPPORTED_MARKETS[0]); // Default Pakistan
  const [adSpend, setAdSpend] = useState<number>(selectedMarket.defaultSpend);
  const [targetRoas, setTargetRoas] = useState<number>(selectedMarket.defaultRoas);
  const [aov, setAov] = useState<number>(selectedMarket.defaultAov);

  // Switch market and update defaults
  const handleMarketChange = (market: MarketConfig) => {
    setSelectedMarket(market);
    setAdSpend(market.defaultSpend);
    setTargetRoas(market.defaultRoas);
    setAov(market.defaultAov);
  };

  const projectedRevenue = Math.round(adSpend * targetRoas);
  const netAdProfit = Math.round(projectedRevenue - adSpend);
  const estimatedOrders = Math.round(projectedRevenue / (aov || 1));

  const recommendation = selectedMarket.getRecommendation(adSpend);

  return (
    <section id="calculator" className="py-20 md:py-28 scroll-mt-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3 mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            <Globe2 className="w-4 h-4" />
            <span>Multi-Country & Multi-Currency Growth Forecasting</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            Calculate Your Ad Returns in Your Local Currency.
          </h2>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            Whether you are running local Cash on Delivery (COD) campaigns in Pakistan or scaling brands in the USA, UK, UAE, or Europe — test your low-to-high budget projections below.
          </p>
        </div>

        {/* Country / Market Selector Tabs */}
        <div className="mb-8">
          <div className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2.5">
            Select Your Target Market & Currency:
          </div>
          <div className="flex flex-wrap gap-2">
            {SUPPORTED_MARKETS.map((m) => {
              const isSelected = selectedMarket.id === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => handleMarketChange(m)}
                  className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition-all duration-200 active:scale-95 ${
                    isSelected
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white shadow-md'
                      : 'bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-800 hover:border-orange-500'
                  }`}
                >
                  <span className="text-base sm:text-lg">{m.flag}</span>
                  <span>{m.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Controls: Input Sliders & Presets */}
          <div className="lg:col-span-6 p-6 sm:p-8 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-8">
            {/* Ad Spend Slider with Direct Numerical Input */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="ad-spend-slider" className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Monthly Advertising Budget ({selectedMarket.currencyCode})
                </label>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl sm:text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                    {formatCurrencyAmount(adSpend, selectedMarket)}
                  </span>
                </div>
              </div>
              <input
                id="ad-spend-slider"
                type="range"
                min={selectedMarket.minSpend}
                max={selectedMarket.maxSpend}
                step={selectedMarket.stepSpend}
                value={adSpend}
                onChange={(e) => setAdSpend(Number(e.target.value))}
                className="w-full h-2.5 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
              <div className="flex justify-between text-[11px] text-neutral-400 font-mono">
                <span>{selectedMarket.spendLabels.low} (Low/Test)</span>
                <span>{selectedMarket.spendLabels.mid}</span>
                <span>{selectedMarket.spendLabels.high} (Scale)</span>
              </div>
            </div>

            {/* Target ROAS Slider */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="target-roas-slider" className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Target / Benchmark ROAS
                </label>
                <span className="text-xl sm:text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                  {targetRoas.toFixed(1)}x
                </span>
              </div>
              <input
                id="target-roas-slider"
                type="range"
                min="2.0"
                max="8.0"
                step="0.1"
                value={targetRoas}
                onChange={(e) => setTargetRoas(Number(e.target.value))}
                className="w-full h-2.5 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
              <div className="flex justify-between text-[11px] text-neutral-400 font-mono">
                <span>2.0x (Break-even)</span>
                <span>5.0x (Shan'S Average)</span>
                <span>8.0x (Viral Scale)</span>
              </div>
            </div>

            {/* Average Order Value (AOV) Selector */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Average Order Value (AOV)
                </label>
                <span className="text-base font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                  {formatCurrencyAmount(aov, selectedMarket)}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {selectedMarket.aovOptions.map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAov(val)}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold font-mono border transition-all ${
                      aov === val
                        ? 'bg-orange-600 text-white border-orange-600 shadow-sm'
                        : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-orange-500'
                    }`}
                  >
                    {formatCurrencyAmount(val, selectedMarket)}
                  </button>
                ))}
              </div>
            </div>

            {/* Market Specific Quick Presets */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
              <div className="text-xs font-medium text-neutral-500">
                Quick Benchmarks for {selectedMarket.shortName}:
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedMarket.presets.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setAdSpend(p.spend);
                      setTargetRoas(p.roas);
                      setAov(p.aov);
                    }}
                    className="px-2.5 py-1.5 text-xs rounded-md bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Cards: Projected Revenue Breakdown & Action */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 sm:p-8 rounded-2xl bg-neutral-900 text-white border border-neutral-800 shadow-xl space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-orange-500" />
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    {selectedMarket.name} Projections
                  </span>
                </div>
                <div className="text-xs font-mono text-emerald-400 font-semibold">
                  ESTIMATED RETURN
                </div>
              </div>

              {/* Big Projected Revenue Output */}
              <div className="space-y-1">
                <div className="text-xs text-neutral-400">Projected Monthly Gross Revenue</div>
                <div className="text-3xl sm:text-5xl font-extrabold font-mono text-white tabular-nums tracking-tight">
                  <span className="text-orange-500">{selectedMarket.currencySymbol} </span>
                  {projectedRevenue.toLocaleString()}
                </div>
              </div>

              {/* Net Ad Profit & Orders */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <div className="text-xs text-neutral-400">Estimated Gross Margin</div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                    +{formatCurrencyAmount(netAdProfit, selectedMarket)}
                  </div>
                  <div className="text-[11px] text-neutral-400">Revenue minus Ad Spend</div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <div className="text-xs text-neutral-400">Estimated Orders</div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">
                    {estimatedOrders.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-neutral-400">At {formatCurrencyAmount(aov, selectedMarket)} AOV</div>
                </div>
              </div>

              {/* Estimated Net Business Profit (Factoring ~30% COGS + 15% OpEx) */}
              <div className="p-4 rounded-xl bg-neutral-800/60 border border-neutral-700/50 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-neutral-300">Estimated Net Bottom-Line Profit</div>
                  <div className="text-[10px] text-neutral-400">Factoring ~30% Product COGS & 15% Shipping/OpEx</div>
                </div>
                <div className="text-lg sm:text-xl font-bold font-mono text-emerald-400">
                  +{formatCurrencyAmount(Math.round(projectedRevenue * 0.55 - adSpend), selectedMarket)}
                </div>
              </div>

              {/* Tailored Tactical Plan for selected Market */}
              <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-orange-400 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Shan'S Recommended Campaign Strategy</span>
                </div>
                <div className="text-sm font-semibold text-white">
                  {recommendation.strategy}
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {recommendation.focus}
                </p>
                <div className="p-2.5 rounded-lg bg-orange-950/40 border border-orange-900/40 text-[11px] text-orange-300">
                  <strong className="text-white">Market Dynamic:</strong> {recommendation.marketInsight}
                </div>
                <div className="text-[11px] text-neutral-400 pt-1 font-mono">
                  Target Creative Velocity: {recommendation.creativeVelocity}
                </div>
              </div>

              {/* Direct Booking & WhatsApp Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => onOpenAuditWithSpend(adSpend)}
                  className="flex-1 py-3.5 px-4 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white text-xs sm:text-sm font-bold uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>Scale to {formatCurrencyAmount(projectedRevenue, selectedMarket)}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={`https://wa.me/923000000000?text=${encodeURIComponent(
                    `Hi Shan! I calculated my ad projections for ${selectedMarket.name}:\n• Monthly Budget: ${formatCurrencyAmount(adSpend, selectedMarket)}\n• Target ROAS: ${targetRoas.toFixed(1)}x\n• Projected Sales: ${formatCurrencyAmount(projectedRevenue, selectedMarket)}\n• Market: ${selectedMarket.name}\nCan you help execute this media plan for my store?`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/30 transition-all active:scale-95 whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp This Plan</span>
                </a>
              </div>

              {/* Clear Mathematical Disclaimer */}
              <p className="text-[10px] text-neutral-500 text-center leading-relaxed pt-2 border-t border-neutral-800">
                <strong>Disclaimer:</strong> Projections are algorithmic models based on your selected budget, ROAS, COGS, and AOV inputs. Actual campaign outcomes depend on product appeal, audience maturity, website conversion rate, and fulfillment operations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
