import { Search, Sparkles, TrendingUp, RefreshCw } from 'lucide-react';

export default function ProcessSection() {
  const steps = [
    {
      step: '01',
      title: 'Forensic Audit & Tracking Infrastructure',
      duration: 'Days 1 - 3',
      icon: <Search className="w-5 h-5 text-orange-500" />,
      description:
        'We plug revenue leaks before spending a dollar. We audit historical ad account data, eliminate overlapping audiences, and deploy server-side Meta Conversions API (CAPI) and TikTok Advanced Matching for pristine attribution.',
      deliverable: 'Account Audit Report & Clean CAPI Pipeline',
    },
    {
      step: '02',
      title: 'High-Velocity Creative Testing Matrix',
      duration: 'Days 4 - 10',
      icon: <Sparkles className="w-5 h-5 text-amber-500" />,
      description:
        'We script and test 8–12 direct-response UGC hooks, carousels, and high-contrast motion creatives. We isolate winning variables (Hooks, Body Angles, CTAs) using Dynamic Creative Testing (DCT).',
      deliverable: 'Validation of 2-3 Marquee Winning Creatives',
    },
    {
      step: '03',
      title: 'Algorithmic Scaling & CBO Budget Jumps',
      duration: 'Days 11 - 30',
      icon: <TrendingUp className="w-5 h-5 text-orange-500" />,
      description:
        'Once winning creatives prove high ROAS and low CPA, we scale horizontally and vertically into Advantage+ Shopping and broad CBO setups, deploying Cost Caps to prevent audience fatigue.',
      deliverable: '+150% to +300% Spend Scaling at Target ROAS',
    },
    {
      step: '04',
      title: 'Omnichannel Retargeting & LTV Multiplier',
      duration: 'Ongoing',
      icon: <RefreshCw className="w-5 h-5 text-amber-500" />,
      description:
        'We capture lost carts and maximize Customer Lifetime Value (LTV) through dynamic catalog retargeting, VIP customer lookalikes, and seamless email/SMS marketing synchronization.',
      deliverable: 'Compound Profit & Unshakeable Margins',
    },
  ];

  return (
    <section className="py-20 md:py-28 border-t border-neutral-200 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-3 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            The Shan'S Digital8 Framework
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            From Stalled Ad Sets to Predictable Multi-Six-Figure Scale.
          </h2>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            A battle-tested 4-step execution methodology engineered specifically for modern algorithm-driven advertising.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((item) => (
            <div
              key={item.step}
              className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6 hover:border-orange-500/50 transition-colors"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black font-mono text-orange-600 dark:text-orange-400">
                    {item.step}
                  </span>
                  <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-800">
                    {item.icon}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-mono text-neutral-400 mb-1">{item.duration}</div>
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white leading-snug">
                    {item.title}
                  </h3>
                </div>

                <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-500 dark:text-neutral-400">
                Key Deliverable: <span className="font-semibold text-neutral-900 dark:text-white">{item.deliverable}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
