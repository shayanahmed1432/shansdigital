import React, { useEffect, useState } from 'react';

interface PageLoadingBarProps {
  isNavigating: boolean;
}

export default function PageLoadingBar({ isNavigating }: PageLoadingBarProps) {
  const [progress, setProgress] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let timer1: NodeJS.Timeout;
    let timer2: NodeJS.Timeout;
    let timer3: NodeJS.Timeout;
    let timer4: NodeJS.Timeout;

    if (isNavigating) {
      setVisible(true);
      setProgress(15);

      timer1 = setTimeout(() => {
        setProgress(45);
      }, 60);

      timer2 = setTimeout(() => {
        setProgress(80);
      }, 150);

      timer3 = setTimeout(() => {
        setProgress(95);
      }, 250);
    } else if (visible) {
      setProgress(100);
      timer4 = setTimeout(() => {
        setVisible(false);
        setProgress(0);
      }, 220);
    }

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [isNavigating, visible]);

  if (!visible) return null;

  return (
    <div
      aria-hidden="true"
      className="fixed top-0 left-0 right-0 z-[99999] pointer-events-none"
    >
      {/* Top Gradient Progress Bar */}
      <div
        className="h-[3.5px] bg-gradient-to-r from-orange-600 via-amber-400 to-orange-500 transition-all ease-out"
        style={{
          width: `${progress}%`,
          transitionDuration: progress === 100 ? '150ms' : '220ms',
          boxShadow: '0 0 14px rgba(255, 90, 0, 0.9), 0 0 4px rgba(255, 170, 0, 0.7)',
        }}
      />

      {/* Leading Edge Glow Orb */}
      <div
        className="absolute top-0 h-[3.5px] w-24 bg-gradient-to-r from-transparent to-white opacity-80 blur-[1px] transition-all ease-out"
        style={{
          left: `calc(${progress}% - 96px)`,
          transitionDuration: progress === 100 ? '150ms' : '220ms',
        }}
      />
    </div>
  );
}
