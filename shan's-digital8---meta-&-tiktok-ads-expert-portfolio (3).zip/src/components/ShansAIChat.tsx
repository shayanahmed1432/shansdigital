import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Bot,
  Sparkles,
  MessageCircle,
  Paperclip,
  Image as ImageIcon,
  CheckCircle2,
  Calendar,
  Gift,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  image?: string;
  imageName?: string;
  time: string;
  isAudit?: boolean;
}

interface ShansAIChatProps {
  onOpenAudit: () => void;
  onOpenTrial?: () => void;
  isDark?: boolean;
}

export default function ShansAIChat({ onOpenAudit, onOpenTrial, isDark }: ShansAIChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedImageName, setSelectedImageName] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: "Assalam-o-Alaikum! I am Shan's AI, official growth strategist for Shan'S Digital8. We specialize in Meta Ads, TikTok Ads, Pakistan COD courier delivery funnels (88%+ delivery rate), and international scaling (US, UK, UAE) to 5.8x+ ROAS.\n\n⚡ **FREE AD AUDIT**: Upload your ad post, flyer, or Ads Manager screenshot below for an instant rating, conversion leak analysis, and our **1-Week Free Ads Management Action Plan**!",
      time: 'Just now',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [isOpen, messages, selectedImage]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file (PNG, JPG, JPEG, WEBP).');
      return;
    }

    if (file.size > 12 * 1024 * 1024) {
      alert('File size exceeds 12MB. Please upload a smaller image.');
      return;
    }

    setSelectedImageName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedImage(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
    // Reset file input value so same file can be re-selected if removed
    e.target.value = '';
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    setSelectedImageName(null);
  };

  const handleSend = async (textToSend?: string) => {
    const query = textToSend !== undefined ? textToSend : input;
    const hasImage = !!selectedImage;

    if (!query.trim() && !hasImage) return;
    if (isLoading) return;

    const currentImage = selectedImage;
    const currentImageName = selectedImageName;

    const userText = query.trim() || (hasImage ? "Please provide a complete Free Ad Audit on my attached creative and deliver your 1-Week Free Ads Management Action Plan." : "");

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: userText,
      image: currentImage || undefined,
      imageName: currentImageName || undefined,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    removeSelectedImage();
    setIsLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        text: m.text,
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          history,
          image: currentImage || undefined,
        }),
      });

      const data = await res.json();
      const replyText =
        data.reply ||
        "Shan'S Digital8 can audit and scale your ad campaigns. Feel free to message Shan directly on WhatsApp (+92 333 2327001)!";

      const isAuditResponse =
        hasImage ||
        replyText.includes('AUDIT') ||
        replyText.includes('MANAGEMENT PLAN') ||
        replyText.includes('1-WEEK') ||
        replyText.includes('ROAS');

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        text: replyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isAudit: isAuditResponse,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          text: "I am having a brief connection delay, but you can chat directly with Shan on WhatsApp (+92 333 2327001) for an instant response and your 1-Week Free Ads Management Plan!",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const triggerUploadClick = () => {
    fileInputRef.current?.click();
  };

  const quickPrompts = [
    '📸 Audit My Ad Creative',
    '🇵🇰 Pakistan COD & Bot Setup',
    '🎁 Claim 1-Week Free Trial',
    '🌍 US & UK Brand Scaling',
    '💰 Calculate Ad Budget',
  ];

  const whatsappDirectChat =
    'https://wa.me/923332327001?text=Hi%20Shan,%20I%20am%20chatting%20with%20Shan%27s%20AI%20and%20want%20to%20claim%20the%201-Week%20Free%20Ads%20Management%20Plan!';

  // Format message text with basic formatting (paragraphs, bolding, bullet points, headers)
  const renderFormattedText = (rawText: string) => {
    const lines = rawText.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed text-[12px]">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (!trimmed) {
            return <div key={idx} className="h-1" />;
          }

          // Divider
          if (trimmed.startsWith('━━━') || trimmed === '---') {
            return <div key={idx} className="border-t border-neutral-300 dark:border-neutral-700 my-2" />;
          }

          // Header line
          if (trimmed.startsWith('###') || trimmed.startsWith('**') && trimmed.endsWith('**') && trimmed.length < 50) {
            const cleanTitle = trimmed.replace(/^###\s*/, '').replace(/^\*\*|\*\*$/g, '');
            return (
              <div key={idx} className="font-bold text-orange-600 dark:text-orange-400 text-[12.5px] mt-2 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                <span>{cleanTitle}</span>
              </div>
            );
          }

          // Bullet item
          if (trimmed.startsWith('- ') || trimmed.startsWith('• ') || /^\d+\.\s/.test(trimmed)) {
            const bulletText = trimmed.replace(/^[-•]\s*/, '').replace(/^\d+\.\s*/, '');
            return (
              <div key={idx} className="flex items-start gap-1.5 pl-1">
                <span className="text-orange-500 font-bold leading-tight mt-0.5">•</span>
                <span className="flex-1">
                  {renderInlineFormatting(bulletText)}
                </span>
              </div>
            );
          }

          return <p key={idx}>{renderInlineFormatting(trimmed)}</p>;
        })}
      </div>
    );
  };

  // Helper for bold and links
  const renderInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-neutral-900 dark:text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <>
      {/* Hidden File Input for Image Upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        className="hidden"
        aria-hidden="true"
      />

      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          aria-label="Open Shan's AI Chat & Free Ad Audit"
          className="fixed bottom-[calc(72px+env(safe-area-inset-bottom,0px))] lg:bottom-7 left-3.5 sm:left-6 z-40 group flex items-center gap-2 px-3 py-2 sm:px-4 sm:py-2.5 rounded-full bg-[#111111] text-white shadow-xl shadow-black/40 border border-neutral-700/80 hover:border-orange-500/80 hover:scale-105 active:scale-95 transition-all duration-200 user-select-none"
        >
          <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white shrink-0 shadow-md shadow-orange-600/30">
            <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#111111] animate-pulse" />
          </div>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold leading-tight flex items-center gap-1 whitespace-nowrap">
              <span>Shan's AI</span>
              <span className="text-[9px] bg-orange-500 text-white px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">
                Audit
              </span>
            </span>
            <span className="text-[10px] text-neutral-400 leading-none hidden sm:inline">
              Ad Audit & 1-Wk Plan
            </span>
          </div>
        </button>
      )}

      {/* Slide-Up Chat Window */}
      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed bottom-[calc(72px+env(safe-area-inset-bottom,0px))] lg:bottom-6 left-3 sm:left-6 z-50 w-[calc(100vw-24px)] sm:w-[420px] max-w-md h-[560px] max-h-[80vh] bg-white dark:bg-[#111111] rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200"
        >
          {/* Header */}
          <div className="p-3.5 bg-neutral-950 text-white border-b border-neutral-800 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="relative w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center p-1">
                <img
                  src="/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png"
                  alt="Shan's AI"
                  className="w-full h-full object-contain"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-neutral-950" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-sm font-bold text-white">
                  <span>Shan's AI</span>
                  <span className="text-[10px] font-mono text-orange-400 uppercase tracking-wider bg-orange-950/80 px-1.5 py-0.2 rounded border border-orange-800/40">
                    Growth Engine
                  </span>
                </div>
                <div className="text-[11px] text-neutral-400">
                  Ad Audit & Meta Scaling Specialist
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsOpen(false)}
                aria-label="Close chat"
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Actions Bar inside Header */}
          <div className="px-3.5 py-2 bg-neutral-100 dark:bg-neutral-950/80 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between text-[11px] shrink-0">
            <button
              onClick={triggerUploadClick}
              className="text-orange-600 dark:text-orange-400 font-bold hover:underline flex items-center gap-1.5 bg-orange-500/10 px-2 py-1 rounded"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Upload Ad Image for Audit</span>
            </button>
            <a
              href={whatsappDirectChat}
              target="_blank"
              rel="noreferrer"
              className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Shan</span>
            </a>
          </div>

          {/* Messages Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
            {messages.map((m) => {
              const isAssistant = m.role === 'assistant';
              const containsAuditKeywords =
                m.text.includes('AUDIT') ||
                m.text.includes('MANAGEMENT PLAN') ||
                m.text.includes('1-WEEK') ||
                m.text.includes('ROAS');

              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[92%] p-3.5 rounded-2xl ${
                      !isAssistant
                        ? 'bg-orange-600 text-white rounded-br-none shadow-sm'
                        : 'bg-neutral-100 dark:bg-neutral-900/95 text-neutral-800 dark:text-neutral-200 rounded-bl-none border border-neutral-200/80 dark:border-neutral-800'
                    }`}
                  >
                    {/* Render uploaded image in chat */}
                    {m.image && (
                      <div className="mb-2.5 rounded-xl overflow-hidden border border-white/20 dark:border-neutral-700 bg-black/40">
                        <img
                          src={m.image}
                          alt="Ad Creative for Audit"
                          className="w-full max-h-48 object-cover rounded-lg"
                        />
                        <div className="p-1.5 bg-black/60 text-[10px] text-white flex items-center justify-between">
                          <span className="flex items-center gap-1 truncate max-w-[200px]">
                            <ImageIcon className="w-3 h-3 text-orange-400 shrink-0" />
                            {m.imageName || 'Ad Creative'}
                          </span>
                          <span className="text-orange-400 font-semibold uppercase text-[9px]">
                            ⚡ Ad Submitted
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Message content */}
                    {isAssistant ? renderFormattedText(m.text) : <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>}

                    {/* Conversion Action Buttons for Audits & 1-Week Management Plan */}
                    {isAssistant && (m.isAudit || containsAuditKeywords) && (
                      <div className="mt-3.5 pt-3 border-t border-neutral-200 dark:border-neutral-800 space-y-2">
                        <div className="text-[10px] uppercase font-bold tracking-wider text-orange-500 flex items-center gap-1">
                          <Gift className="w-3 h-3" />
                          <span>Special Offer Activated For You:</span>
                        </div>

                        <div className="grid grid-cols-1 gap-1.5">
                          {onOpenTrial && (
                            <button
                              onClick={() => {
                                setIsOpen(false);
                                onOpenTrial();
                              }}
                              className="w-full py-2 px-3 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-orange-600/20 hover:scale-[1.01] transition-transform"
                            >
                              <Gift className="w-3.5 h-3.5" />
                              <span>Claim 1-Week Free Ads Management</span>
                            </button>
                          )}

                          <div className="flex gap-1.5">
                            <button
                              onClick={() => {
                                setIsOpen(false);
                                onOpenAudit();
                              }}
                              className="flex-1 py-1.5 px-2.5 rounded-lg bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 hover:text-orange-500 font-semibold text-[11px] flex items-center justify-center gap-1 border border-neutral-300 dark:border-neutral-700 transition-colors"
                            >
                              <Calendar className="w-3 h-3 text-orange-500" />
                              <span>Book Call</span>
                            </button>

                            <a
                              href={whatsappDirectChat}
                              target="_blank"
                              rel="noreferrer"
                              className="flex-1 py-1.5 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] flex items-center justify-center gap-1 transition-colors text-center"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>WhatsApp Shan</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-neutral-400 mt-1 px-1">{m.time}</span>
                </div>
              );
            })}

            {isLoading && (
              <div className="flex flex-col gap-1.5 p-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 w-fit rounded-bl-none border border-neutral-200 dark:border-neutral-800">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-bounce [animation-delay:0.4s]" />
                  <span className="text-[11px] font-semibold text-orange-500 ml-1">
                    Analyzing ad metrics & creating 1-week plan...
                  </span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Suggestions */}
          {messages.length <= 2 && (
            <div className="px-3 py-1.5 bg-neutral-50 dark:bg-neutral-900 border-t border-neutral-200 dark:border-neutral-800 flex gap-1.5 overflow-x-auto no-scrollbar shrink-0">
              {quickPrompts.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (q.includes('Audit')) {
                      triggerUploadClick();
                    } else {
                      handleSend(q);
                    }
                  }}
                  className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:text-orange-600 dark:hover:text-orange-400 border border-neutral-200 dark:border-neutral-700 whitespace-nowrap shrink-0 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Image Upload Preview Bar */}
          {selectedImage && (
            <div className="px-3 py-2 bg-orange-500/10 border-t border-orange-500/30 flex items-center justify-between text-xs shrink-0">
              <div className="flex items-center gap-2 truncate">
                <img
                  src={selectedImage}
                  alt="Thumbnail"
                  className="w-8 h-8 rounded object-cover border border-orange-500/50"
                />
                <div className="truncate">
                  <div className="font-semibold text-neutral-800 dark:text-neutral-200 text-[11px] truncate">
                    {selectedImageName || 'Ad Creative'}
                  </div>
                  <div className="text-[10px] text-orange-600 dark:text-orange-400">
                    Ready for Free AI Audit
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={removeSelectedImage}
                className="p-1 rounded-full hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
                aria-label="Remove image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Input Bar */}
          <div className="p-3 bg-white dark:bg-neutral-950 border-t border-neutral-200 dark:border-neutral-800 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-1.5"
            >
              {/* Paperclip / Image Upload Button */}
              <button
                type="button"
                onClick={triggerUploadClick}
                title="Upload Ad Image or Screenshot for Free Audit"
                aria-label="Upload Ad Image or Screenshot"
                className="p-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300 hover:text-orange-500 transition-colors shrink-0 border border-neutral-200 dark:border-neutral-700"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <input
                ref={inputRef}
                type="text"
                placeholder={selectedImage ? "Add ad notes or hit send to audit..." : "Ask Shan's AI or upload your ad creative..."}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isLoading}
                className="flex-1 px-3 py-2 text-xs rounded-xl bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-orange-500"
              />

              <button
                type="submit"
                disabled={(!input.trim() && !selectedImage) || isLoading}
                aria-label="Send message"
                className="p-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 disabled:opacity-40 text-white transition-colors shrink-0 shadow-sm"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
