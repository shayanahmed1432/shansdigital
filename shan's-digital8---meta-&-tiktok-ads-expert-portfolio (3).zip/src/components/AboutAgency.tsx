import { useState } from 'react';
import { FAQS } from '../data/portfolioData';
import { ChevronDown, ShieldCheck, Zap, HeartHandshake, Eye } from 'lucide-react';

export default function AboutAgency() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <section id="agency" className="py-20 md:py-28 border-t border-neutral-200 dark:border-neutral-800 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          {/* Left Column: Brand Lockup & Visual Card */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-2xl p-6 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xl space-y-6">
              <div className="rounded-xl overflow-hidden bg-neutral-950 p-6 border border-neutral-800 flex flex-col items-center justify-center text-center space-y-3 shadow-inner">
                <img
                  src="/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png"
                  alt="Shan'S Digital8 - Innovative Software & Digital Solutions"
                  className="w-24 h-24 object-contain filter drop-shadow-lg"
                  referrerPolicy="no-referrer"
                />
                <div className="text-2xl font-black tracking-tight text-white">
                  <span className="text-orange-500">Shan'S</span> Digital8
                </div>
                <div className="text-[10px] uppercase font-bold tracking-widest text-neutral-400">
                  Innovative Software & Digital Solutions
                </div>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
                  The Founder's Commitment
                </div>
                <h3 className="text-xl font-bold text-neutral-900 dark:text-white">
                  &ldquo;We treat your advertising budget with the same respect as our own capital.&rdquo;
                </h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Founded by performance media buyer Shan, Shan'S Digital8 was built to bridge the gap between creative storytelling and mathematical ad account optimization.
                </p>
              </div>

              <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="text-neutral-400">Primary Specialization</div>
                  <div className="font-semibold text-neutral-900 dark:text-white">Meta & TikTok Ads</div>
                </div>
                <div>
                  <div className="text-neutral-400">Headquarters</div>
                  <div className="font-semibold text-neutral-900 dark:text-white">Global Remote Agency</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Agency Philosophy & Core Pillars */}
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Why Brands Choose Shan'S Digital8
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
              Obsessed with Cash Flow, Not Vanity Impressions.
            </h2>
            <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
              Most generic marketing agencies hide behind vanity metrics like &quot;brand awareness&quot;, &quot;reach&quot;, and &quot;video views&quot;.
              At Shan'S Digital8, we judge every campaign by one simple metric: <strong>did it put profitable revenue into your bank account?</strong>
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 dark:text-white">
                  <ShieldCheck className="w-4 h-4 text-orange-500" />
                  <span>100% Account Ownership</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  You own all ad accounts, custom pixels, and creative assets. Everything is transparent inside your Business Manager.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 dark:text-white">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>Algorithmic Optimization</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  We don't rely on outdated hacks. We align directly with Meta & TikTok AI machine-learning algorithms to get maximum auction efficiency.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 dark:text-white">
                  <Eye className="w-4 h-4 text-orange-500" />
                  <span>Weekly Video Reporting</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  No confusing 40-page PDFs. We record weekly video walkthroughs breaking down exact spend, wins, creative tests, and next actions.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 dark:text-white">
                  <HeartHandshake className="w-4 h-4 text-amber-500" />
                  <span>Zero Hostage Contracts</span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  We operate on performance and mutual respect. We earn your partnership month-to-month by delivering undeniable ROAS.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Frequently Asked Questions */}
        <div className="pt-12 border-t border-neutral-200 dark:border-neutral-800">
          <div className="max-w-3xl mb-10 space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Clear Answers
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white">
              Frequently Asked Questions
            </h3>
          </div>

          <div className="max-w-4xl space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-neutral-900 dark:text-white text-base hover:text-orange-500 transition-colors"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-5 h-5 text-neutral-400 shrink-0 transition-transform duration-200 ${
                        isOpen ? 'rotate-180 text-orange-500' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed border-t border-neutral-100 dark:border-neutral-800">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
