import { TESTIMONIALS } from '../data/portfolioData';
import { Quote, Star, CheckCircle } from 'lucide-react';

export default function Testimonials() {
  return (
    <section className="py-20 md:py-28 bg-neutral-50/60 dark:bg-neutral-900/40 border-t border-neutral-200 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-3 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            Client Endorsements & Proof
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            Trusted by Ambitious Founders and Growth Leaders.
          </h2>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            Real feedback from brand owners and growth directors whose ad accounts we scaled to 5x+ ROAS.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((test) => (
            <div
              key={test.id}
              className="p-8 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6 hover:border-orange-500/50 transition-colors"
            >
              <div className="space-y-4">
                {/* 5 Stars + Verified Review */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-orange-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-orange-500" />
                    ))}
                  </div>
                  <div className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Verified Client</span>
                  </div>
                </div>

                {/* Key Outcome Highlight */}
                <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
                  Result: {test.metricsResult}
                </div>

                <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed italic">
                  &ldquo;{test.quote}&rdquo;
                </p>
              </div>

              {/* Attribution */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center font-bold text-white text-sm">
                  {test.clientName.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold text-neutral-900 dark:text-white">
                    {test.clientName}
                  </div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">
                    {test.role} · {test.company}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {test.companyType}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
