import { useState } from 'react';
import { ArrowRight, TrendingUp, Sparkles, ShieldCheck, Play, MessageCircle } from 'lucide-react';

interface HeroProps {
  onOpenAudit: () => void;
  onExploreServices?: () => void;
  isDark?: boolean;
}

export default function Hero({ onOpenAudit, onExploreServices, isDark }: HeroProps) {
  const [activeTab, setActiveTab] = useState<'meta' | 'tiktok'>('meta');

  return (
    <section className="relative overflow-hidden w-full max-w-full pt-8 pb-16 md:pt-16 md:pb-24">
      {/* Ambient energetic glowing background orbs matching logo orange */}
      <div
        className="absolute top-1/4 -left-48 w-96 h-96 bg-orange-500/10 dark:bg-orange-600/20 rounded-full blur-3xl pointer-events-none animate-pulse-subtle"
        aria-hidden="true"
      />
      <div
        className="absolute top-10 right-0 w-[30rem] h-[30rem] bg-amber-500/10 dark:bg-orange-500/15 rounded-full blur-3xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(242,92,5,0.05),transparent_60%)] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            {/* Editorial Kicker with brand mark reference */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              <img
                src={
                  isDark
                    ? '/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png'
                    : '/assets/aistudio/final_logo-removebg-preview_083f68f6.png'
                }
                alt="Logo Mark"
                className="w-5 h-5 object-contain inline-block filter drop-shadow-sm transition-opacity duration-300"
              />
              <span>Shan'S Digital8</span>
              <span aria-hidden="true">·</span>
              <span>Full-Service Digital Marketing & E-Commerce Growth</span>
            </div>

            {/* Dominant Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-neutral-950 dark:text-white leading-[1.08] [text-wrap:balance]">
              Grow Your Business With Smart Digital Marketing &{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500">
                Performance Advertising.
              </span>
            </h1>

            {/* Body Prose */}
            <p className="text-lg sm:text-xl text-neutral-600 dark:text-neutral-300 font-normal leading-relaxed max-w-2xl">
              We help businesses attract customers, generate quality leads and grow online through strategic advertising, creative marketing and e-commerce management.
            </p>

            {/* CTAs - Explore Our Services, Get Free Ads Audit, WhatsApp Us */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-2 w-full">
              <button
                onClick={onExploreServices}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-white bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-xl shadow-md transition-all duration-200 transform hover:-translate-y-0.5 active:scale-95 whitespace-nowrap min-h-[44px]"
              >
                <span>Explore Our Services</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenAudit}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 rounded-xl shadow-lg shadow-orange-600/25 hover:shadow-orange-600/40 transition-all duration-200 transform hover:-translate-y-0.5 active:scale-95 whitespace-nowrap min-h-[44px]"
              >
                <span>Get Free Ads Audit</span>
                <Sparkles className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/923332327001?text=Hi!%20I%20want%20to%20know%20more%20about%20your%20digital%20marketing%20services."
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap min-h-[44px]"
                title="Chat with Shan on WhatsApp"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Us</span>
              </a>
            </div>

            {/* Trust Badges - unboxed clean inline metadata */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-6 pt-4 text-xs font-medium text-neutral-500 dark:text-neutral-400 border-t border-neutral-200 dark:border-neutral-800/80">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Official Meta Ads & CAPI Certified</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                <span>High-Converting UGC Creative Pipeline</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Average Client ROAS 5.8x</span>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Ad Performance Showcase */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl p-1 bg-gradient-to-b from-orange-500/30 via-neutral-800/50 to-neutral-900/60 dark:from-orange-500/40 dark:via-neutral-800/80 dark:to-neutral-950 shadow-2xl">
              <div className="rounded-[14px] bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 p-6 space-y-6">
                {/* Header Switcher */}
                <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-neutral-950 p-1 border border-neutral-800 flex items-center justify-center shadow-sm">
                      <img
                        src="/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png"
                        alt="Shan'S Digital8"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-neutral-900 dark:text-white uppercase tracking-wider">
                        Live Campaign Blueprint
                      </div>
                      <div className="text-[11px] text-neutral-500">
                        Real algorithmic scaling engine
                      </div>
                    </div>
                  </div>

                  {/* Interactive Platform Switcher */}
                  <div className="flex items-center p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs font-semibold">
                    <button
                      onClick={() => setActiveTab('meta')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        activeTab === 'meta'
                          ? 'bg-orange-600 text-white shadow-sm'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                      }`}
                    >
                      Meta Ads
                    </button>
                    <button
                      onClick={() => setActiveTab('tiktok')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        activeTab === 'tiktok'
                          ? 'bg-orange-600 text-white shadow-sm'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                      }`}
                    >
                      TikTok Ads
                    </button>
                  </div>
                </div>

                {/* Campaign Dynamic View */}
                {activeTab === 'meta' ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs text-neutral-500">
                      <span>Campaign: ASC+ E-Commerce Blitz</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        STATUS: ACTIVE SCALING
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Blended ROAS</div>
                        <div className="text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                          6.42x
                        </div>
                        <div className="text-[11px] text-emerald-600 font-medium">+184% vs industry avg</div>
                      </div>
                      <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Revenue Generated</div>
                        <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                          $184,520
                        </div>
                        <div className="text-[11px] text-neutral-500">13,040 verified orders</div>
                      </div>
                    </div>

                    {/* Creative Snapshot Preview */}
                    <div className="p-3.5 rounded-xl bg-neutral-900 text-neutral-200 text-xs space-y-2 border border-neutral-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-white">Winning Creative: Problem-Hook Reel</span>
                        <span className="text-orange-400 font-mono">3.8% CTR</span>
                      </div>
                      <p className="text-neutral-400 text-[12px] leading-relaxed">
                        &quot;Why 90% of buyers were using the wrong setup...&quot; Dynamic product demo
                        with instant shop tag + 1-click checkout.
                      </p>
                      <div className="flex items-center gap-3 pt-1 text-[11px] text-neutral-400">
                        <span>Cost Per Purchase: <strong className="text-white font-mono">$14.15</strong></span>
                        <span aria-hidden="true">·</span>
                        <span>CAPI Match: <strong className="text-emerald-400">98%</strong></span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs text-neutral-500">
                      <span>Campaign: Viral UGC Spark Scaling</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        STATUS: VIRAL RUN
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">TikTok ROAS</div>
                        <div className="text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                          5.91x
                        </div>
                        <div className="text-[11px] text-emerald-600 font-medium">1.2M+ Real Views</div>
                      </div>
                      <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60">
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Total Attributed Sales</div>
                        <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                          $248,125
                        </div>
                        <div className="text-[11px] text-neutral-500">Spend: $42,350</div>
                      </div>
                    </div>

                    {/* Creative Snapshot Preview */}
                    <div className="p-3.5 rounded-xl bg-neutral-900 text-neutral-200 text-xs space-y-2 border border-neutral-800">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-white">Top Spark Ad: Creator Unboxing #01</span>
                        <span className="text-orange-400 font-mono">68% Retention</span>
                      </div>
                      <p className="text-neutral-400 text-[12px] leading-relaxed">
                        Unfiltered TikTok creator unboxing reacting to instant results with native voiceover
                        and high-urgency limited stock caption.
                      </p>
                      <div className="flex items-center gap-3 pt-1 text-[11px] text-neutral-400">
                        <span>Avg Watch: <strong className="text-white font-mono">14.1s</strong></span>
                        <span aria-hidden="true">·</span>
                        <span>CPA: <strong className="text-emerald-400 font-mono">$25.50</strong></span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Audit trigger banner */}
                <div className="pt-2">
                  <button
                    onClick={onOpenAudit}
                    className="w-full py-2.5 px-4 rounded-lg bg-neutral-900 dark:bg-neutral-800 hover:bg-neutral-800 dark:hover:bg-neutral-700 text-white text-xs font-semibold flex items-center justify-between border border-neutral-700/60 transition-colors"
                  >
                    <span>Audit your Meta or TikTok Ads with Shan</span>
                    <span className="text-orange-400 flex items-center gap-1">
                      Free Audit <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
