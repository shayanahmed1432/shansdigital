import { useState, useEffect } from 'react';
import { ClientResult, CaseStudy, CategoryFilter } from '../types';
import { getStoredResults } from '../data/resultsData';
import {
  TrendingUp,
  CheckCircle2,
  ExternalLink,
  Eye,
  ShieldCheck,
  ArrowUpDown,
  Filter,
  Sparkles,
  Layers,
  ShoppingBag,
  MapPin
} from 'lucide-react';

interface ResultsGalleryProps {
  onSelectCaseStudy?: (study: CaseStudy) => void;
  onOpenAudit: () => void;
}

export default function ResultsGallery({
  onSelectCaseStudy,
  onOpenAudit,
}: ResultsGalleryProps) {
  const [results, setResults] = useState<ClientResult[]>([]);
  const [filter, setFilter] = useState<CategoryFilter>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'roas' | 'leads'>('latest');
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  useEffect(() => {
    // Load from resultsData helper which checks localStorage or defaults
    const list = getStoredResults();
    // Only show published results publicly
    setResults(list.filter((r) => r.status === 'published'));
  }, []);

  // Filter items
  const filtered = results.filter((item) => {
    if (filter === 'all') return true;
    if (filter === 'meta') return item.platform === 'Meta Ads' || item.platform === 'Both';
    if (filter === 'tiktok') return item.platform === 'TikTok Ads' || item.platform === 'Both';
    if (filter === 'ecommerce') return item.category === 'ecommerce';
    if (filter === 'leadgen') return item.category === 'leadgen';
    if (filter === 'local') return item.category === 'local';
    return true;
  });

  // Sort items
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'roas') {
      const roasA = parseFloat(a.roas.replace(/[^0-9.]/g, '')) || 0;
      const roasB = parseFloat(b.roas.replace(/[^0-9.]/g, '')) || 0;
      return roasB - roasA;
    }
    if (sortBy === 'leads') {
      const leadsA = parseInt(a.leads?.replace(/[^0-9]/g, '') || '0', 10);
      const leadsB = parseInt(b.leads?.replace(/[^0-9]/g, '') || '0', 10);
      return leadsB - leadsA;
    }
    // Default: latest updated
    return new Date(b.updatedAt || '2025-01-01').getTime() - new Date(a.updatedAt || '2025-01-01').getTime();
  });

  return (
    <section id="results" className="py-20 md:py-28 relative scroll-mt-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-neutral-200 dark:border-neutral-800">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              <ShieldCheck className="w-4 h-4" />
              <span>LATEST CLIENT RESULTS · REAL VERIFIED AD PROOF</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
              Authentic Performance. Multi-Million Return On Ad Spend.
            </h2>
            <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-300">
              Zero invented client accounts. Real campaign dashboards across Pakistan (PKR & COD), USA (USD), UK (GBP), and UAE (AED). 
              Every metric reflects true advertising data.
            </p>
          </div>

          {/* Quick Sort Dropdown */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-neutral-500 font-medium">
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Sort By:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs font-semibold py-2 px-3 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="latest">Latest Updated</option>
              <option value="roas">Highest ROAS</option>
              <option value="leads">Most Leads Generated</option>
            </select>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800 w-full max-w-full overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All Results' },
            { id: 'meta', label: 'Meta Ads (FB & IG)' },
            { id: 'tiktok', label: 'TikTok Ads' },
            { id: 'ecommerce', label: 'E-commerce & COD' },
            { id: 'leadgen', label: 'B2B & Lead Gen' },
            { id: 'local', label: 'Local Businesses' },
          ].map((tab) => {
            const isActive = filter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id as CategoryFilter)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-white dark:bg-neutral-800 text-orange-600 dark:text-orange-400 shadow-sm'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Dynamic Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sorted.map((item) => (
            <div
              key={item.id}
              className="group rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between"
            >
              {/* Card Header & Proof Image */}
              <div>
                <div
                  onClick={() => item.screenshotUrl && setPreviewImage(item.screenshotUrl)}
                  className="relative h-44 w-full bg-neutral-900 overflow-hidden cursor-pointer"
                >
                  {item.screenshotUrl ? (
                    <img
                      src={item.screenshotUrl}
                      alt={`${item.clientName} ad dashboard proof`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-950 text-neutral-600 text-xs">
                      Live Ads Manager Proof
                    </div>
                  )}

                  {/* Badges Overlay */}
                  <div className="absolute top-3 inset-x-3 flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/70 backdrop-blur-md text-white border border-white/20">
                      {item.platform}
                    </span>

                    {item.isProjection ? (
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/90 text-white shadow-md">
                        Projection
                      </span>
                    ) : item.verified ? (
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-600/90 text-white shadow-md flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Verified Live</span>
                      </span>
                    ) : null}
                  </div>

                  {item.screenshotUrl && (
                    <button
                      onClick={() => setPreviewImage(item.screenshotUrl || null)}
                      className="absolute bottom-3 right-3 p-2 rounded-lg bg-black/60 hover:bg-black/80 text-white backdrop-blur-sm transition-colors text-[10px] font-bold flex items-center gap-1"
                      title="Inspect Dashboard Screenshot"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Inspect Proof</span>
                    </button>
                  )}
                </div>

                {/* Card Content Body */}
                <div className="p-6 space-y-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-neutral-400">
                      <MapPin className="w-3 h-3 text-orange-500" />
                      <span>{item.country}</span>
                      <span>·</span>
                      <span>{item.currency}</span>
                    </div>
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white group-hover:text-orange-500 transition-colors line-clamp-1">
                      {item.clientName}
                    </h3>
                  </div>

                  {/* 4 Metric KPI Grid */}
                  <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-900/80 border border-neutral-100 dark:border-neutral-800">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block">Ad Spend</span>
                      <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">{item.spend}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block">Revenue</span>
                      <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">{item.revenue}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block">Return (ROAS)</span>
                      <span className="text-sm font-black text-orange-600 dark:text-orange-400">{item.roas}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block">
                        {item.purchases ? 'Orders' : item.leads ? 'Leads' : 'Result'}
                      </span>
                      <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">
                        {item.purchases || item.leads || item.cpa || item.cpl || 'Verified'}
                      </span>
                    </div>
                  </div>

                  {/* Strategic Summary */}
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed line-clamp-2">
                    {item.summary}
                  </p>
                </div>
              </div>

              {/* Card Footer Action */}
              <div className="px-6 pb-6 pt-2 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between">
                <span className="text-[10px] text-neutral-400">
                  Updated {item.updatedAt}
                </span>

                <button
                  onClick={onOpenAudit}
                  className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:text-orange-500 flex items-center gap-1 transition-colors"
                >
                  <span>Replicate In Your Brand</span>
                  <span>→</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Screenshot Lightbox Modal */}
        {previewImage && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/95 backdrop-blur-md animate-in fade-in duration-200"
            onClick={() => setPreviewImage(null)}
          >
            <div
              className="relative max-w-5xl w-full bg-neutral-950 rounded-2xl sm:rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl p-2 sm:p-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 px-2 border-b border-neutral-800/80 mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    Live Meta Ads Manager Verification Proof
                  </span>
                </div>
                <button
                  onClick={() => setPreviewImage(null)}
                  className="px-3 py-1 rounded-full bg-neutral-800 text-white text-xs font-bold hover:bg-neutral-700 transition-colors"
                >
                  Close (ESC) ✕
                </button>
              </div>
              <div className="overflow-auto max-h-[82vh] rounded-xl flex items-center justify-center bg-black/50">
                <img
                  src={previewImage}
                  alt="Live Ad Account Dashboard Proof"
                  className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
                />
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
