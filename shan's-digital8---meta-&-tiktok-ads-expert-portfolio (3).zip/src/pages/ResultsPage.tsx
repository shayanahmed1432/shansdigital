import { CaseStudy, PageRoute } from '../types';
import ResultsGallery from '../components/ResultsGallery';
import { CASE_STUDIES } from '../data/portfolioData';
import {
  ArrowLeft,
  ShieldCheck,
  Award,
  CheckCircle2,
  TrendingUp,
  MessageCircle,
  Lock,
  ArrowRight
} from 'lucide-react';

interface ResultsPageProps {
  onSelectCaseStudy: (study: CaseStudy) => void;
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function ResultsPage({ onSelectCaseStudy, onOpenAudit, onNavigate }: ResultsPageProps) {
  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-orange-500 flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Verified Client Results & Proof</span>
        </div>

        {/* Dynamic Results Gallery with Filter & Sort */}
        <ResultsGallery
          onSelectCaseStudy={onSelectCaseStudy}
          onOpenAudit={onOpenAudit}
        />

        {/* Deep-Dive Case Studies Blueprint Section */}
        <div className="space-y-8 pt-8 border-t border-neutral-200 dark:border-neutral-800">
          <div className="max-w-3xl space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-500">
              In-Depth Tactical Breakdowns
            </span>
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              Full Campaign Blueprints & Strategy Studies
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Click any case study below to open the complete tactical breakdown including audience structures, hook formulations, and ROAS scaling timelines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {CASE_STUDIES.map((study) => (
              <div
                key={study.id}
                onClick={() => onSelectCaseStudy(study)}
                className="group p-6 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 shadow-md hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-orange-500 uppercase tracking-wider">
                      {study.platform} · {study.category}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Verified</span>
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-neutral-900 dark:text-white group-hover:text-orange-500 transition-colors">
                    {study.title}
                  </h3>

                  <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-900 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-400 block font-bold">SPEND</span>
                      <span className="font-extrabold text-neutral-800 dark:text-neutral-200">{study.results.spend}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block font-bold">REVENUE</span>
                      <span className="font-black text-emerald-500">{study.results.revenue}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-400 block font-bold">ROAS</span>
                      <span className="font-black text-orange-500">{study.results.roas}</span>
                    </div>
                  </div>

                  <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-2">
                    {study.challenge}
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-bold text-orange-500">
                  <span>View Case Study Blueprint</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA Banner */}
        <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900 border border-neutral-800 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <h3 className="text-2xl sm:text-3xl font-black">
              Want similar results for your business?
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Book a free ad account audit or claim your 7-Day Free Meta Ads Management Trial today.
            </p>
          </div>
          <button
            onClick={onOpenAudit}
            className="px-8 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shrink-0"
          >
            Claim Free Ad Audit
          </button>
        </div>
      </div>
    </div>
  );
}
