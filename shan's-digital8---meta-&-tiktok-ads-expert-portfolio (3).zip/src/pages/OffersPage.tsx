import { useState } from 'react';
import { PageRoute } from '../types';
import {
  Gift,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  MessageCircle,
  FileSearch,
  Users,
  Send,
  AlertCircle
} from 'lucide-react';

interface OffersPageProps {
  onOpenAudit: () => void;
  onOpenTrial: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function OffersPage({ onOpenAudit, onOpenTrial, onNavigate }: OffersPageProps) {
  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Special Agency Offers</span>
        </div>

        {/* Page Hero Header */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-600 dark:text-orange-400 text-xs font-bold uppercase tracking-wider">
            <Gift className="w-4 h-4" />
            <span>Risk-Free Growth Opportunities</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-neutral-900 dark:text-white leading-[1.1] [text-wrap:balance]">
            Exclusive Agency Offers For High-Growth Brands.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            We believe in proving our value through execution before locking you into long-term retainer agreements. 
            Choose an offer below to experience Shan'S Digital8 performance engineering.
          </p>
        </div>

        {/* FEATURED OFFER 1: 7-DAY FREE TRIAL */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#141414] to-neutral-950 border-2 border-orange-500/50 p-8 sm:p-12 text-white shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-orange-500/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="space-y-4 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 text-[11px] font-bold uppercase tracking-wider border border-orange-500/30">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Most Popular · Limited Weekly Slots</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black tracking-tight">
                7 DAYS FREE META ADS MANAGEMENT TRIAL
              </h2>

              <p className="text-sm text-neutral-300 leading-relaxed">
                Experience professional advertising management for seven days without paying a management fee. 
                Our senior team handles your campaign architecture, creative hooks, and ad setup. You fund your ad spend directly inside your own Meta account with 100% transparency.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-neutral-300 pt-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Management fee waived for 7 full days</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>100% direct client ad account ownership</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Zero automatic contract roll-over</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Full campaign transparency & daily updates</span>
                </div>
              </div>
            </div>

            <div className="w-full lg:w-auto shrink-0 flex flex-col gap-3">
              <button
                onClick={onOpenTrial}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 hover:from-orange-500 hover:to-orange-600 text-white font-black text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-500/30 transform hover:-translate-y-0.5 active:scale-95 text-center"
              >
                CLAIM YOUR 7-DAY FREE TRIAL
              </button>
              <span className="text-[10px] text-center text-neutral-400">
                Requires active business & approved ad account
              </span>
            </div>
          </div>
        </div>

        {/* 2-COLUMN OFFERS: 100% Free Audit + Free Strategy Consultation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Offer 2: 100% Free Meta Ads Audit */}
          <div className="p-8 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                <FileSearch className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                  Account Deep-Dive
                </span>
                <h3 className="text-2xl font-black text-neutral-900 dark:text-white">
                  100% FREE META ADS ACCOUNT AUDIT
                </h3>
              </div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                If you are currently spending money on Facebook and Instagram ads and feel your ROAS is slipping or CPMs are too high, let Shan inspect your account.
              </p>

              <div className="space-y-2 pt-2 text-xs text-neutral-700 dark:text-neutral-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Campaign structure & budget overlap review</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Audience targeting & creative fatigue check</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>CAPI & pixel tracking event match audit</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Clear action plan delivered in 24 hours</span>
                </div>
              </div>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              <button
                onClick={onOpenAudit}
                className="flex-1 py-3.5 px-4 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-bold text-xs uppercase tracking-wider hover:bg-orange-600 dark:hover:bg-orange-500 dark:hover:text-white transition-colors text-center"
              >
                GET MY FREE ADS AUDIT
              </button>
              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20want%20to%20request%20the%20100%25%20Free%20Meta%20Ads%20Audit."
                target="_blank"
                rel="noreferrer"
                className="py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 shrink-0"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Offer 3: Free Strategy Consultation */}
          <div className="p-8 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  1-on-1 Growth Session
                </span>
                <h3 className="text-2xl font-black text-neutral-900 dark:text-white">
                  FREE MARKETING STRATEGY CONSULTATION
                </h3>
              </div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                A private 20-minute video or audio call with Shan to analyze your business model, profit margins, COD courier return rates, and multi-channel expansion.
              </p>

              <div className="space-y-2 pt-2 text-xs text-neutral-700 dark:text-neutral-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Review unit economics & product breakeven ROAS</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Pakistan local COD delivery optimization blueprint</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Cross-border US/UK/UAE scaling roadmap</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Zero pressure, high-value tactical feedback</span>
                </div>
              </div>
            </div>

            <div className="pt-4">
              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20would%20like%20to%20schedule%20a%20Free%20Marketing%20Strategy%20Consultation."
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Schedule Strategy Call via WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
