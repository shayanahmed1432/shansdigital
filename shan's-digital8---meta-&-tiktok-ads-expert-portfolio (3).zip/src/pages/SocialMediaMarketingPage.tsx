import { PageRoute } from '../types';
import {
  Share2,
  Calendar,
  Image,
  Video,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ShieldAlert,
  Flame,
  MessageCircle,
  Clock
} from 'lucide-react';

interface SocialMediaMarketingPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function SocialMediaMarketingPage({ onOpenAudit, onNavigate }: SocialMediaMarketingPageProps) {
  const services = [
    {
      icon: <Share2 className="w-6 h-6 text-orange-500" />,
      title: 'Facebook Page Management',
      desc: 'Complete day-to-day administration of your official Facebook page. Post scheduling, banner refreshes, about section updates, and customer messaging setup.',
    },
    {
      icon: <Sparkles className="w-6 h-6 text-pink-500" />,
      title: 'Instagram Account Management',
      desc: 'Curated 9-grid aesthetic, bio optimization, story highlights structure, and seamless product tagging linked with your store catalog.',
    },
    {
      icon: <Flame className="w-6 h-6 text-amber-500" />,
      title: 'Social Media Strategy',
      desc: 'Custom growth blueprint built around your target demographic in Pakistan, GCC, or Western markets. Defining content pillars, brand tone, and audience hooks.',
    },
    {
      icon: <Image className="w-6 h-6 text-orange-500" />,
      title: 'Graphic Post & Carousel Design',
      desc: 'High-contrast, brand-consistent carousels, infographics, and single posts designed to maximize saves, shares, and profile visits.',
    },
    {
      icon: <Video className="w-6 h-6 text-red-500" />,
      title: 'Reels & Short Video Planning',
      desc: 'Trending audio curation, 3-second hook scripting, b-roll direction, and caption copywriting optimized for Instagram Explore and viral feeds.',
    },
    {
      icon: <Calendar className="w-6 h-6 text-blue-500" />,
      title: 'Monthly Content Calendar',
      desc: '30-day organized calendar prepared in advance. You review and approve every post graphic, caption, and scheduled date before publishing.',
    },
    {
      icon: <MessageSquare className="w-6 h-6 text-emerald-500" />,
      title: 'Community Engagement & Moderation',
      desc: 'Prompt replies to comments and direct messages, filtering spam, escalating sales inquiries to your team, and nurturing loyal followers.',
    },
    {
      icon: <CheckCircle2 className="w-6 h-6 text-orange-500" />,
      title: 'Page Optimization & Audit',
      desc: 'Strategic bio keyword optimization, custom link-in-bio hub setup, cover photo redesign, and verification readiness checks.',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => onNavigate('services')} className="hover:text-orange-500 transition-colors">
            Services
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Social Media Marketing (Organic)</span>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 border border-neutral-800 p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-400 text-xs font-bold uppercase tracking-wider">
              <Share2 className="w-4 h-4" />
              <span>Organic Brand Building & Community Growth</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] [text-wrap:balance]">
              Build An Authentic Brand Audience That Loves To Buy.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
              We turn dormant social media profiles into vibrant, high-trust storefronts. 
              Consistent aesthetics, viral reels, engaging carousels, and disciplined monthly publishing that nurtures followers into repeat customers.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40"
              >
                <span>Request Social Strategy Audit</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20am%20interested%20in%20Social%20Media%20Marketing%20for%20my%20brand."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Shan Directly</span>
              </a>
            </div>
          </div>
        </div>

        {/* Paid vs Organic Distinction Notice */}
        <div className="p-6 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs leading-relaxed flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-sm font-bold text-neutral-900 dark:text-white mb-0.5">
              Clear Agency Distinction: Organic Social Media vs Paid Advertising
            </strong>
            <span>
              <strong>Organic Social Media Marketing</strong> (this page) focuses on profile aesthetics, community trust, viral reels, and content consistency. 
              <strong> Paid Advertising</strong> (Meta Ads & TikTok Ads) focuses on instant customer acquisition, ROAS, and scalable purchases. For highest growth, our premier clients combine both channels.
            </span>
          </div>
        </div>

        {/* Services Grid */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              Complete Social Media Management
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Everything required to elevate your brand presence on Facebook and Instagram without you lifting a finger.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all shadow-sm space-y-3"
              >
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800/80 w-fit">
                  {item.icon}
                </div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 30-Day Content Workflow */}
        <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900 border border-neutral-800 text-white space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-orange-400">
              Our Publishing Process
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">
              How We Run Your Social Channels Every Month
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-neutral-800/60 border border-neutral-700/60 space-y-3">
              <span className="text-2xl font-black text-orange-500">01</span>
              <h4 className="text-sm font-bold text-white">Strategy & Monthly Calendar</h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                By the 25th of each month, we plan the upcoming 30 days of posts, reels, and stories based on upcoming holidays, product launches, and seasonal trends.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-neutral-800/60 border border-neutral-700/60 space-y-3">
              <span className="text-2xl font-black text-orange-500">02</span>
              <h4 className="text-sm font-bold text-white">Creative Production & Review</h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Our design team crafts bespoke carousels and edits high-hook vertical reels. You review the complete batch and approve with 1 click.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-neutral-800/60 border border-neutral-700/60 space-y-3">
              <span className="text-2xl font-black text-orange-500">03</span>
              <h4 className="text-sm font-bold text-white">Automated Scheduling & Engagement</h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Posts go live at peak engagement hours. We monitor responses, moderate spam, and prepare a monthly growth report detailing reach and follower retention.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center max-w-xl mx-auto space-y-4">
          <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
            Ready to revamp your brand's social image?
          </h3>
          <p className="text-xs text-neutral-600 dark:text-neutral-400">
            Let Shan audit your existing social profiles and map out an organic growth blueprint.
          </p>
          <button
            onClick={onOpenAudit}
            className="px-8 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
          >
            Claim Free Social Audit
          </button>
        </div>
      </div>
    </div>
  );
}
