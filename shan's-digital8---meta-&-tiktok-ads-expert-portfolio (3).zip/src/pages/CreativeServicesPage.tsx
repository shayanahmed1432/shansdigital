import { PageRoute } from '../types';
import CreativeAnatomy from '../components/CreativeAnatomy';
import {
  Video,
  Sparkles,
  Layers,
  Palette,
  FileText,
  Flame,
  ArrowRight,
  MessageCircle,
  Eye,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

interface CreativeServicesPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function CreativeServicesPage({ onOpenAudit, onNavigate }: CreativeServicesPageProps) {
  const capabilities = [
    {
      icon: <Palette className="w-6 h-6 text-orange-500" />,
      title: 'Ad Graphic Design & Carousels',
      desc: 'High-converting static banners, split-screen comparison posts, multi-slide product carousels, and promotional sale graphics crafted with intense visual hierarchy.',
    },
    {
      icon: <Video className="w-6 h-6 text-red-500" />,
      title: 'Video Ad Editing & Concepts',
      desc: 'Pacing, sound effects, subtitles, kinetic text typography, and dynamic b-roll sequencing designed specifically for TikTok, Instagram Reels, and YouTube Shorts.',
    },
    {
      icon: <Flame className="w-6 h-6 text-amber-500" />,
      title: 'High-Converting Ad Hooks',
      desc: '3-second psychological scroll-stoppers: visual curiosity gaps, negative-to-positive twists, problem-demonstration zooms, and relatable Roman Urdu / English dialogue hooks.',
    },
    {
      icon: <FileText className="w-6 h-6 text-blue-500" />,
      title: 'Direct-Response Ad Copywriting',
      desc: 'Headlines, primary text, and link descriptions engineered using PAS (Problem-Agitate-Solve) and AIDA formulas that push emotional desire into immediate action.',
    },
    {
      icon: <Layers className="w-6 h-6 text-purple-500" />,
      title: 'UGC Content Planning & Scripting',
      desc: 'Full scene-by-scene actor scripts, shot lists, and talking points for content creators and customers reviewing your product naturally.',
    },
    {
      icon: <RefreshCw className="w-6 h-6 text-emerald-500" />,
      title: 'Creative Fatigue Refresh System',
      desc: 'A systematic weekly cadence replacing fatigued hooks with fresh winning angles, keeping CPMs low and blended ROAS consistent month after month.',
    },
  ];

  const hookVault = [
    {
      type: 'Curiosity Gap Hook',
      script: '"I tested 5 different Pakistani clothing brands so you don’t have to waste your money..."',
      why: 'Generates instant objective trust and positions your review as genuine consumer intelligence.',
      retention: '42% 3-sec Hold Rate',
    },
    {
      type: 'Problem Identification Hook',
      script: '"If your courier deliveries are stuck below 65%, stop changing your ad settings and do this instead..."',
      why: 'Targets the single biggest pain point of Pakistani D2C store owners (COD return rate).',
      retention: '48% 3-sec Hold Rate',
    },
    {
      type: 'Direct Contrast Hook',
      script: '"Why are US apparel brands paying $35 for an order when this 1 setting brought ours down to $16?"',
      why: 'Highlights radical efficiency and triggers competitive curiosity.',
      retention: '51% 3-sec Hold Rate',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => onNavigate('services')} className="hover:text-orange-500 transition-colors">
            Services
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Creative Services & Ad Hooks</span>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 border border-neutral-800 p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Direct-Response Creative Lab</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] [text-wrap:balance]">
              Creatives Are The New Targeting. We Build Ads That Convert.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
              In modern advertising algorithms, media buying settings matter less than high-retention video creatives, thumb-stopping hooks, and irresistible offers. 
              We research, script, design, and edit high-velocity direct-response assets built for performance.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40"
              >
                <span>Request Creative Review</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20want%20to%20upgrade%20my%20ad%20creatives%20and%20hooks."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Shan</span>
              </a>
            </div>
          </div>
        </div>

        {/* Capabilities Grid */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              Creative Production Capabilities
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Everything your brand needs to maintain a continuous stream of fresh, winning ad creatives.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {capabilities.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all shadow-sm space-y-3"
              >
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800/80 w-fit">
                  {item.icon}
                </div>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Integrated Creative Anatomy breakdown */}
        <div className="relative">
          <CreativeAnatomy />
        </div>

        {/* Real Hook Showcase */}
        <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900 border border-neutral-800 text-white space-y-6">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-orange-400">
              Battle-Tested Hooks
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">
              Inside Our Hook Formulation Vault
            </h3>
            <p className="text-xs text-neutral-400 max-w-xl">
              Here are examples of high-converting hooks formulated for local and international campaigns:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {hookVault.map((item, idx) => (
              <div key={idx} className="p-6 rounded-2xl bg-neutral-800/70 border border-neutral-700/60 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-orange-400 uppercase tracking-wider">{item.type}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {item.retention}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-sm italic font-medium text-white">
                  {item.script}
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">{item.why}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Banner */}
        <div className="text-center max-w-xl mx-auto space-y-4">
          <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
            Need high-converting ad visuals and reels?
          </h3>
          <p className="text-xs text-neutral-600 dark:text-neutral-400">
            Let Shan audit your creative fatigue and share 5 customized video hook angles for your brand.
          </p>
          <button
            onClick={onOpenAudit}
            className="px-8 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
          >
            Claim Free Creative Audit
          </button>
        </div>
      </div>
    </div>
  );
}
