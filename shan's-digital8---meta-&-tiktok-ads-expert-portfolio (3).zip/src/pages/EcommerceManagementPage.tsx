import { PageRoute } from '../types';
import {
  ShoppingBag,
  TrendingUp,
  Search,
  Box,
  Tag,
  Store,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  MessageCircle,
  AlertTriangle,
  Globe
} from 'lucide-react';

interface EcommerceManagementPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function EcommerceManagementPage({ onOpenAudit, onNavigate }: EcommerceManagementPageProps) {
  const platforms = [
    {
      name: 'Shopify Store Optimization',
      badge: 'D2C Flagship',
      desc: 'Conversion Rate Optimization (CRO), product page layout enhancements, post-purchase upsell funnels, and checkout flow streamline to maximize Average Order Value (AOV).',
    },
    {
      name: 'TikTok Shop Management',
      badge: 'Rapid Scale',
      desc: 'Complete marketplace setup, product catalog synchronization, affiliate creator outreach, in-app promotional discount management, and compliance handling.',
    },
    {
      name: 'Daraz Account Management',
      badge: 'Pakistan & South Asia',
      desc: 'Daraz Mall and seller center optimization: Mega Sale campaigns (11.11, 12.12), store design optimization, voucher mechanics, and review generation.',
    },
    {
      name: 'Amazon Account Support',
      badge: 'Global Marketplace',
      desc: 'Listing optimization with keyword-rich titles, bullet points, backend search terms, A+ content planning, and PPC advertising campaign coordination.',
    },
    {
      name: 'eBay & Etsy Account Support',
      badge: 'International Reach',
      desc: 'Cross-border listing architecture, SEO tag alignment, international shipping profile configuration, and multi-currency product pricing strategy.',
    },
  ];

  const corePillars = [
    {
      icon: <Search className="w-6 h-6 text-orange-500" />,
      title: 'Product Research & Competitor Benchmarking',
      desc: 'Discovering trending winning products, analyzing competitor pricing curves, margins, and customer complaints to create a superior brand positioning.',
    },
    {
      icon: <Tag className="w-6 h-6 text-amber-500" />,
      title: 'High-Converting Product Listing Optimization',
      desc: 'Crafting persuasive descriptions, feature-benefit bullet points, high-resolution lifestyle infographics, and SEO keywords that drive organic ranking.',
    },
    {
      icon: <Box className="w-6 h-6 text-blue-500" />,
      title: 'Inventory & Order Workflow Support',
      desc: 'Streamlining fulfillment workflows, COD courier integrations (PostEx, Trax, Leopards), order validation to reduce Return-To-Origin (RTO), and restocking alerts.',
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-emerald-500" />,
      title: 'Promotional Campaign Setup & Bundles',
      desc: 'Configuring irresistible BOGO deals, tiered discounts, festive sale campaigns, and automated cart-recovery sequences that convert hesitant visitors.',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => onNavigate('services')} className="hover:text-orange-500 transition-colors">
            Services
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">E-commerce Management & Growth</span>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 border border-neutral-800 p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShoppingBag className="w-4 h-4" />
              <span>Full-Spectrum E-Commerce Operations</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] [text-wrap:balance]">
              Scale Your Online Store Across Shopify, TikTok Shop & Marketplaces.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
              We handle the complex operations, product optimizations, listings, and promotion mechanics so you can focus on inventory and brand vision. 
              Built for ambitious brands selling locally in Pakistan and globally across the US, UK, and UAE.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40"
              >
                <span>Request Store Growth Audit</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20am%20interested%20in%20E-commerce%20Store%20Management."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Shan</span>
              </a>
            </div>
          </div>
        </div>

        {/* Clear Policy: No Web Development */}
        <div className="p-6 rounded-2xl bg-orange-500/10 border border-orange-500/30 text-neutral-800 dark:text-neutral-200 text-xs leading-relaxed flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-sm font-bold text-neutral-900 dark:text-white mb-0.5">
              Service Scope Notice: Focused On Growth, Operations & Marketing
            </strong>
            <span>
              Shan'S Digital8 provides end-to-end e-commerce store management, marketing, product listing optimization, and scaling. 
              <strong> We do not provide generic website development services.</strong> Our dedicated focus is on maximizing conversions, Average Order Value (AOV), sales velocity, and gross revenue on your existing storefronts and marketplace accounts.
            </span>
          </div>
        </div>

        {/* Supported Platforms */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              Platforms & Marketplaces We Manage
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Expert operational management tailored to the unique mechanics of each platform.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {platforms.map((p, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                    <Store className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-orange-600 dark:text-orange-400 border border-neutral-200 dark:border-neutral-700">
                    {p.badge}
                  </span>
                </div>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">{p.name}</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Core Pillars */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              Complete Store Growth Pillars
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {corePillars.map((pillar, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all shadow-sm flex items-start gap-4"
              >
                <div className="p-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 shrink-0">
                  {pillar.icon}
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white">{pillar.title}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{pillar.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA Card */}
        <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900 border border-neutral-800 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <h3 className="text-2xl sm:text-3xl font-black">
              Ready to streamline and scale your e-commerce operations?
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Book a 15-minute consultation with Shan to review your store conversion rate, courier delivery rates, and listing ranking opportunities.
            </p>
          </div>
          <button
            onClick={onOpenAudit}
            className="px-8 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shrink-0"
          >
            Claim Free Store Audit
          </button>
        </div>
      </div>
    </div>
  );
}
