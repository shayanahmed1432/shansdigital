import { PageRoute } from '../types';
import AboutAgency from '../components/AboutAgency';
import Testimonials from '../components/Testimonials';
import { ArrowLeft, ShieldCheck, Zap, Eye, HeartHandshake, ArrowRight, MessageCircle } from 'lucide-react';

interface AboutPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
  isDark: boolean;
}

export default function AboutPage({ onOpenAudit, onNavigate, isDark }: AboutPageProps) {
  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-orange-500 flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">About Shan'S Digital8</span>
        </div>

        {/* Page Header */}
        <div className="max-w-3xl space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            About The Founder & The Agency
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-950 dark:text-white leading-[1.1] [text-wrap:balance]">
            Built by Media Buyers. Driven by Real Profit.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            Shan'S Digital8 was founded on a simple principle: businesses don't need another generic agency that hides behind vanity reach. They need direct-response advertising that generates cash collected at profitable ROAS.
          </p>
        </div>

        {/* Agency Component with Logos & FAQs */}
        <AboutAgency />

        {/* Testimonials */}
        <Testimonials />

        {/* Bottom Callout */}
        <div className="p-8 sm:p-10 rounded-2xl bg-gradient-to-r from-orange-600 to-orange-500 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Work Directly With Shan & Our Senior Team
            </h3>
            <p className="text-sm text-orange-100 max-w-xl">
              We only take on 3 new brand scaling partnerships each month to ensure dedicated attention. Book your audit today.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={onOpenAudit}
              className="w-full sm:w-auto px-7 py-3.5 text-xs font-bold uppercase tracking-wider text-neutral-950 bg-white hover:bg-neutral-100 rounded-xl shadow-lg transition-all active:scale-95 whitespace-nowrap min-h-[44px]"
            >
              Claim Free Ad Audit
            </button>
            <a
              href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20read%20about%20your%20agency%20and%20want%20to%20partner%20with%20you."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-600 rounded-xl shadow-lg transition-all active:scale-95 whitespace-nowrap flex items-center justify-center gap-2 min-h-[44px]"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Shan</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
