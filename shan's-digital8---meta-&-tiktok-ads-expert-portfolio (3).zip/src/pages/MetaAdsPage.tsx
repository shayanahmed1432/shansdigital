import { useState } from 'react';
import { PageRoute } from '../types';
import {
  Layers,
  Sparkles,
  BarChart3,
  Cpu,
  Target,
  Video,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Gift,
  MessageCircle,
  FileSearch,
  Zap,
  TrendingUp,
  Award
} from 'lucide-react';

interface MetaAdsPageProps {
  onOpenAudit: () => void;
  onOpenTrial: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function MetaAdsPage({ onOpenAudit, onOpenTrial, onNavigate }: MetaAdsPageProps) {
  const [activeTab, setActiveTab] = useState<'campaigns' | 'strategy' | 'creatives' | 'tracking'>('campaigns');

  const campaignServices = [
    { title: 'Facebook Ads Management', desc: 'Precision campaign scaling utilizing Advantage+ and high-intent demographic clusters.' },
    { title: 'Instagram Ads Management', desc: 'High-aesthetic Feed, Stories, and Reels placements optimized for impulse checkouts.' },
    { title: 'WhatsApp Ads', desc: 'Direct-to-chat Click-to-WhatsApp funnels that build trust and close sales rapidly in Pakistan and GCC.' },
    { title: 'Messenger Campaigns', desc: 'Automated conversational lead qualification and customer service bots inside Meta Messenger.' },
    { title: 'Lead Generation Campaigns', desc: 'Native high-converting Instant Forms with phone validation for B2B, real estate, and clinics.' },
    { title: 'Sales & Conversion Campaigns', desc: 'Full-funnel catalog and dynamic ads built for profitable bottom-line revenue.' },
    { title: 'Website Traffic Campaigns', desc: 'High-quality outbound traffic driving pre-qualified visitors to landing pages.' },
    { title: 'Brand Awareness Campaigns', desc: 'Omnipresent localized reach cementing brand authority across target geographic territories.' },
    { title: 'Retargeting Campaigns', desc: 'Dynamic remarketing to cart abandoners, previous visitors, and engaged social followers.' },
    { title: 'Local Business Advertising', desc: 'Geo-radius targeting for physical retail stores, aesthetic clinics, and local service providers.' },
  ];

  const strategyServices = [
    { title: 'Business & Unit Economics Analysis', desc: 'Calculating exact breakeven ROAS, shipping loss margins, and target CPA before spending ad dollars.' },
    { title: 'Competitor & Auction Research', desc: 'Deep-dive into Meta Ad Library to identify competitor hooks, angles, offers, and weaknesses.' },
    { title: 'Customer Avatar & Psychology Research', desc: 'Uncovering the deepest emotional pain points and purchasing desires of your exact buyer persona.' },
    { title: 'Audience Targeting Architecture', desc: 'Segmenting Broad, Lookalikes, and Custom audience clusters for algorithmic learning.' },
    { title: 'Campaign Objective Selection', desc: 'Aligning Meta’s algorithmic optimization goals strictly with cash in your bank account.' },
    { title: 'Campaign Structure Planning', desc: 'Eliminating ad account fragmentation using unified Advantage+ and modular testing sandboxes.' },
    { title: 'Budget Allocation Planning', desc: 'Scientific 70/20/10 budget distribution (70% scaling winners, 20% testing hooks, 10% retargeting).' },
    { title: 'Algorithmic Scaling Strategy', desc: 'Safe horizontal and vertical budget expansion without shocking the auction or resetting learning phase.' },
  ];

  const creativeServices = [
    { title: 'Facebook Ad Creatives', desc: 'High-contrast graphic and carousel creatives designed to interrupt rapid thumb scrolling.' },
    { title: 'Instagram Ad Creatives', desc: 'Native 9:16 vertical storytelling reels and polished lifestyle visuals that fit Instagram culture.' },
    { title: 'Promotional Graphics', desc: 'Urgency-driven sale banners, bundle graphics, and holiday promotional assets.' },
    { title: 'Direct-Response Ad Copywriting', desc: 'Compelling primary text utilizing PAS (Problem-Agitate-Solve) and AIDA formulas.' },
    { title: 'Headlines & Link Descriptions', desc: 'Punchy click triggers and risk-reversal subheads that maximize outbound CTR.' },
    { title: 'Video Ad Concepts & Storyboarding', desc: 'Scene-by-scene blueprints engineered with 3-second visual hooks and emotional payoffs.' },
    { title: 'Reels Ad Strategy', desc: 'Fast-paced, authentic vertical video formats optimized for Meta’s highest-reach algorithmic surface.' },
    { title: 'UGC Creative Planning', desc: 'Guiding customer and creator unboxings, reviews, and Roman Urdu/English testimonials.' },
    { title: 'Dynamic Creative Testing (DCT)', desc: 'Modular testing matrix (3 hooks x 2 bodies x 2 headlines) identifying breakout winners reliably.' },
  ];

  const trackingServices = [
    { title: 'Meta Pixel Setup & Verification', desc: 'Flawless client-side pixel implementation with full domain verification and aggregated events.' },
    { title: 'Conversions API Setup (Server-Side CAPI)', desc: 'Direct server-to-server tracking bypassing iOS 14.5 restrictions and ad blockers for 95%+ event match quality.' },
    { title: 'Standard & Custom Event Tracking', desc: 'Tracking PageView, ViewContent, AddToCart, InitiateCheckout, Lead, and Purchase with granular parameters.' },
    { title: 'Custom Audiences Building', desc: 'Building high-value 30/60/180-day buyer lists, 75% video viewers, and engaged Instagram profiles.' },
    { title: 'Lookalike Audiences Modeling', desc: 'Generating 1% to 5% high-affinity lookalikes modeled after your highest-AOV repeat purchasers.' },
    { title: 'Scientific A/B Testing', desc: 'Strict split tests across hooks, landing pages, and offers with statistical significance verification.' },
    { title: 'Daily Campaign Monitoring', desc: 'Active monitoring of frequency, CPM fluctuations, ROAS velocity, and auction overlap.' },
    { title: 'Ongoing Campaign Optimization', desc: 'Pruning fatigued creatives, adjusting cost caps, and reallocating spend to winning ad sets.' },
    { title: 'Transparent Performance Reporting', desc: 'Clear, jargon-free bi-weekly and monthly reports detailing exact spend, revenue, and net profit.' },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Header Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => onNavigate('services')} className="hover:text-orange-500 transition-colors">
            Services
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Meta Ads Management (Flagship)</span>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 border border-neutral-800 p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/20 border border-orange-500/40 text-orange-400 text-xs font-bold uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>Flagship Performance Channel</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] [text-wrap:balance]">
              Turn Your Advertising Into Real Business Opportunities.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
              We manage end-to-end Facebook and Instagram advertising for ambitious Pakistani and international businesses. 
              From deep market research and high-converting video hooks to server-side Conversions API (CAPI) and algorithmic scaling — we treat your ad budget like our own investment.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenTrial}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40 transform hover:-translate-y-0.5 active:scale-95"
              >
                <Gift className="w-4 h-4" />
                <span>Claim 7-Day Free Trial</span>
              </button>

              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider border border-neutral-700 transition-all active:scale-95"
              >
                <FileSearch className="w-4 h-4 text-orange-400" />
                <span>Get Free Ads Audit</span>
              </button>

              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20am%20interested%20in%20your%20Meta%20Ads%20Management%20service."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all active:scale-95"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Shan</span>
              </a>
            </div>
          </div>
        </div>

        {/* 7-Day Free Trial Spotlight Card */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-orange-950/40 via-neutral-900 to-amber-950/30 border border-orange-500/40 relative overflow-hidden">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-3 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-400">
                <Gift className="w-4 h-4" />
                <span>Featured Promotional Offer</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white">
                7 DAYS FREE META ADS MANAGEMENT TRIAL
              </h2>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Experience Shan'S Digital8 professional ad management for 7 full days without paying an agency management fee. You only fund your ad spend directly inside your Meta Ad Account. See our workflow, communication, and strategy firsthand.
              </p>
              <div className="flex flex-wrap gap-4 text-xs text-neutral-500 dark:text-neutral-400 pt-1">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  Management fee waived
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  Direct ad account access
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  No long-term contracts
                </span>
              </div>
            </div>

            <button
              onClick={onOpenTrial}
              className="px-8 py-4 rounded-2xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-black text-xs uppercase tracking-wider shadow-2xl shadow-orange-500/30 shrink-0 transform hover:-translate-y-0.5 active:scale-95 transition-all"
            >
              CLAIM YOUR 7-DAY FREE TRIAL
            </button>
          </div>
        </div>

        {/* The 4 Core Pillars Interactive Tabs */}
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-orange-500">
              Complete Capabilities
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
              The 4 Pillars of Our Meta Ads System
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-300">
              Every client campaign is engineered through four disciplined phases. Explore each pillar below:
            </p>
          </div>

          {/* Navigation Pill Buttons */}
          <div className="flex items-center justify-start sm:justify-center gap-2 p-1.5 bg-neutral-100 dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 w-full max-w-3xl mx-auto overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab('campaigns')}
              className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === 'campaigns'
                  ? 'bg-white dark:bg-neutral-800 text-orange-600 dark:text-orange-400 shadow-md'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>1. Campaigns</span>
            </button>
            <button
              onClick={() => setActiveTab('strategy')}
              className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === 'strategy'
                  ? 'bg-white dark:bg-neutral-800 text-orange-600 dark:text-orange-400 shadow-md'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Target className="w-4 h-4" />
              <span>2. Strategy</span>
            </button>
            <button
              onClick={() => setActiveTab('creatives')}
              className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === 'creatives'
                  ? 'bg-white dark:bg-neutral-800 text-orange-600 dark:text-orange-400 shadow-md'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Video className="w-4 h-4" />
              <span>3. Creatives</span>
            </button>
            <button
              onClick={() => setActiveTab('tracking')}
              className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === 'tracking'
                  ? 'bg-white dark:bg-neutral-800 text-orange-600 dark:text-orange-400 shadow-md'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>4. Tracking & CAPI</span>
            </button>
          </div>

          {/* Active Tab Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
            {activeTab === 'campaigns' &&
              campaignServices.map((item, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 transition-all shadow-sm space-y-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                    <Layers className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}

            {activeTab === 'strategy' &&
              strategyServices.map((item, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 transition-all shadow-sm space-y-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                    <Target className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}

            {activeTab === 'creatives' &&
              creativeServices.map((item, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 transition-all shadow-sm space-y-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                    <Video className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}

            {activeTab === 'tracking' &&
              trackingServices.map((item, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 transition-all shadow-sm space-y-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}
          </div>
        </div>

        {/* Free Meta Ads Audit Banner */}
        <div className="rounded-3xl bg-neutral-900 border border-neutral-800 p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
              Already Running Ads?
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">
              Get A 100% Free Meta Ads Account Audit
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Shan will personally examine your ad account architecture, CAPI event match rate, high-CPA ad sets, and creative fatigue. Delivered with actionable recommendations in 24 hours.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <button
              onClick={onOpenAudit}
              className="px-6 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
            >
              Get Free Audit
            </button>
            <a
              href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20want%20to%20get%20my%20Meta%20Ads%20account%20audited."
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider border border-neutral-700 transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>WhatsApp Shan</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
