import { PageRoute } from '../types';
import CreativeAnatomy from '../components/CreativeAnatomy';
import { ArrowLeft, Sparkles, Video, ArrowRight, MessageCircle, Eye, Flame, Award, ShieldCheck } from 'lucide-react';

interface CreativeLabPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function CreativeLabPage({ onOpenAudit, onNavigate }: CreativeLabPageProps) {
  const testingRules = [
    {
      rule: '01. The 3-Second Rule',
      desc: 'If your 3-second hook rate is under 30%, the algorithm penalties will double your CPMs. We produce 4 distinct hook angles for every 1 concept.',
    },
    {
      rule: '02. Dynamic Creative Testing (DCT)',
      desc: 'We launch 3 Hooks, 2 Bodies, and 2 Headlines in an isolated sandbox ad set, letting Meta AI find the winning combination before scaling budget.',
    },
    {
      rule: '03. Native UGC Over Polished Studio',
      desc: 'Raw iPhone footage with relatable creators and real lighting consistently outperforms expensive $10k commercial shoots by 2.4x in ROAS.',
    },
    {
      rule: '04. Fast Creative Refreshes',
      desc: 'To prevent ad fatigue on winning campaigns, we refresh hooks and lead-ins every 7 to 10 days without changing the core winning offer.',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-orange-500 flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Creative Strategy Lab</span>
        </div>

        {/* Page Header */}
        <div className="max-w-3xl space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>Direct-Response Creative Engineering</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-950 dark:text-white leading-[1.1] [text-wrap:balance]">
            Creative is the New Targeting.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            In modern algorithm-driven advertising, audience interests no longer dictate success — your ad creative does.
            Here is how Shan'S Digital8 scripts, produces, and iterates on ads that stop the scroll and lower your CPA.
          </p>
        </div>

        {/* Main Creative Anatomy Widget */}
        <div className="rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm overflow-hidden p-2 sm:p-6">
          <CreativeAnatomy />
        </div>

        {/* 4 Creative Testing Rules */}
        <div className="p-8 sm:p-10 rounded-2xl bg-neutral-950 text-white border border-neutral-800 space-y-8">
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              The 4 Rules of High-ROAS Creative Testing
            </h2>
            <p className="text-sm text-neutral-400 max-w-xl">
              Strict rules we enforce across all our Meta Reels and TikTok ad creative pipelines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testingRules.map((r, idx) => (
              <div key={idx} className="p-6 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="text-sm font-bold text-orange-400 font-mono">{r.rule}</div>
                <p className="text-xs text-neutral-300 leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Callout */}
        <div className="p-8 sm:p-10 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
              Suffering from Ad Fatigue or High CPAs?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 max-w-xl">
              Send us your top 3 ad creatives. Shan will record a video teardown pointing out the exact retention drop-offs and offer improvements.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={onOpenAudit}
              className="w-full sm:w-auto px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap min-h-[44px]"
            >
              Get Creative Teardown
            </button>
            <a
              href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20want%20you%20to%20audit%20and%20review%20my%20ad%20creatives."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-5 py-3.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap flex items-center justify-center gap-2 min-h-[44px]"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Shan</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
