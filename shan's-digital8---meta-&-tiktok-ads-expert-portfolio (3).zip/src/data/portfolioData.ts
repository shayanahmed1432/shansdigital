import { CaseStudy, Testimonial } from '../types';

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'meta-sales-42-roas',
    title: 'Meta Ads Sales Blitz: 42.8x ROAS with Rs. 15.38 Cost Per Purchase',
    client: 'E-Commerce Fashion & Apparel (Karachi & Lahore)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: '42.8x',
    heroMetricLabel: 'Blended ROAS',
    image: '/assets/aistudio/Meta_Ads_Manager_Sales_Campaign_Dashboard_f4fd209b.png',
    results: {
      spend: 'Rs. 1,186.73',
      revenue: 'Rs. 50,890.00',
      roas: '42.83x',
      cpa: 'Rs. 15.38 CPA',
      impressions: '77 Verified Purchases',
    },
    challenge:
      'The client suffered from high customer acquisition costs (Rs. 600+ CPA) on outdated interest-targeting campaigns, rendering their local Pakistani e-commerce store unprofitable.',
    solution:
      'Restructured account into an Advantage+ Sales campaign powered by rapid mobile-first video reels, dynamic creative testing, and automated WhatsApp order confirmation.',
    keyTactics: [
      'Isolated top-performing ad sets achieving astronomical 47.57x and 42.61x individual ROAS',
      'Acquired 77 verified customer checkouts at an average cost of only Rs. 15.38',
      'Configured Meta Conversions API (CAPI) for 95%+ event match quality on Shopify',
      'Scaled budget with algorithmic bid pacing without degrading ROAS performance',
    ],
    timeline: '30-Day Campaign Sprint',
    verifiedBadge: true,
  },
  {
    id: 'whatsapp-leads-2874',
    title: '1,055,953 Impressions to 2,874 Qualified Messaging Orders at Rs. 13.57',
    client: 'High-Volume D2C Direct Messaging Engine (Pakistan)',
    platform: 'Meta Ads',
    category: 'leadgen',
    heroMetric: '2,874',
    heroMetricLabel: 'Buyer Inquiries',
    image: '/assets/aistudio/Facebook_Ads_Manager_Performance_Snapshot_62d28125.png',
    results: {
      spend: 'Rs. 39,064.00',
      revenue: 'Rs. 420,000+ Closed',
      roas: '10.75x Pipeline',
      cpa: 'Rs. 13.57 / Message',
      impressions: '1,055,953 Impressions',
    },
    challenge:
      'Traditional web store checkout was experiencing cart drop-offs due to lack of buyer trust and high Cash-on-Delivery (COD) return friction across provincial cities.',
    solution:
      'Engineered a high-velocity direct WhatsApp messaging acquisition funnel that pre-qualified buyers and converted inquiries in real-time with automated chat assistance.',
    keyTactics: [
      'Reached 710,594 targeted buyers across Punjab, Sindh, and Islamabad with over 1 Million impressions',
      'Stabilized acquisition cost at an astonishing Rs. 13.57 per qualified customer conversation',
      'Scaled 4 powerhouse ad sets simultaneously delivering 842, 683, 739, and 512 buyer chats',
      'Integrated Trax and PostEx courier booking webhooks directly from chat confirmations',
    ],
    timeline: 'October Scale Blitz',
    verifiedBadge: true,
  },
  {
    id: 'ar-jewelry-scaling',
    title: 'AR Jewelry: 84 Orders & High-Ticket WhatsApp Consultations at Sub-Rs. 38 CPA',
    client: 'AR Jewelry (Luxury Accessories & COD Funnel)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: '12.4x',
    heroMetricLabel: 'Campaign ROAS',
    image: '/assets/aistudio/3_395cbecb.jpg',
    results: {
      spend: 'Rs. 3,876.39',
      revenue: 'Rs. 48,200.00',
      roas: '12.43x',
      cpa: 'Rs. 35.74 CPA',
      impressions: '14,012 Impressions',
    },
    challenge:
      'Selling high-ticket jewelry online in Pakistan required overcoming trust barriers regarding authentic finish, metal quality, and safe courier delivery.',
    solution:
      'Created close-up macro 4K product unboxing videos highlighting packaging and certification, paired with immediate WhatsApp sizing guidance.',
    keyTactics: [
      'Delivered 84 verified jewelry purchases at sub-Rs. 38 CPA across the AR Jewelry campaigns',
      'Captured 71 direct high-ticket WhatsApp client chats at Rs. 14.62 per conversation',
      'Targeted affluent female demographic in DHA, Clifton, Gulberg, and Bahria Town',
      'Implemented 100% inspection-on-delivery guarantee raising courier acceptance to 91%',
    ],
    timeline: 'Continuous Scale',
    verifiedBadge: true,
  },
  {
    id: 'direct-sales-funnel-15roas',
    title: 'Direct-Response E-Commerce: 45 Purchases with Peak Ads at 42.6x ROAS',
    client: 'Consumer DTC Brand (Pakistan)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: '15.4x',
    heroMetricLabel: 'Blended ROAS',
    image: '/assets/aistudio/Facebook_Ads_Manager_Sales_Overview_5e317c8a.png',
    results: {
      spend: 'Rs. 1,842.14',
      revenue: 'Rs. 28,440.00',
      roas: '15.44x',
      cpa: 'Rs. 18.05 CPA',
      impressions: '45 Purchases',
    },
    challenge:
      'Small initial testing budget requiring rapid positive cash flow from ad spend without burning through capital.',
    solution:
      'Launched razor-sharp Meta sales campaigns focusing on high-converting bundle promotions with direct checkout.',
    keyTactics: [
      'Top winning creative hook delivered Rs. 15,960 conversion value on just Rs. 374 spend (42.61x ROAS)',
      'Second winning ad generated Rs. 12,480 conversion value on Rs. 340 spend (36.75x ROAS)',
      'Average cost per purchase maintained at a rock-bottom Rs. 18.05',
      'Immediate cash reinvestment allowed 3x budget scaling within 10 days',
    ],
    timeline: '14-Day Sprint',
    verifiedBadge: true,
  },
  {
    id: 'pakistan-d2c-scaling',
    title: 'Scaling Pakistani D2C Brand to Rs. 85+ Lacs / Mo with 6.2x ROAS & 89% COD Delivery',
    client: 'Zephyr Studio PK (Karachi & Lahore)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: 'Rs. 85L+',
    heroMetricLabel: 'Monthly Revenue',
    image: '/assets/aistudio/Meta_Ads_Manager_Sales_Campaign_Dashboard_f4fd209b.png',
    results: {
      spend: 'Rs. 13.7 Lacs',
      revenue: 'Rs. 85,240,000',
      roas: '6.22x',
      cpa: 'Rs. 620 CPA',
      impressions: '89% Delivered COD',
    },
    challenge:
      'Stuck with poor Cash-on-Delivery (COD) delivery rates under 62%, high fake-order rates on Shopify, costly return shipments (RTO) eating profit margins, and ad fatigue across local Pakistani cities.',
    solution:
      'Engineered localized Urdu/Roman Urdu UGC unboxings, unified broad Meta Advantage+ campaigns across key cities, automated WhatsApp 1-click order confirmation bot, and integrated PostEx & Trax courier NDR webhooks.',
    keyTactics: [
      'Scripted 12 localized Urdu/Roman Urdu UGC hook reels focused on product durability and hassle-free exchange',
      'Deployed automated WhatsApp COD confirmation bot slashing cancellation and return-to-origin (RTO) by 41%',
      'Scaled broad Advantage+ Shopping campaigns across Lahore, Karachi, Islamabad, Rawalpindi, and Faisalabad',
      'Pushed final successful courier delivery rate from 62% to 89%+, netting unprecedented brand profit in PKR',
    ],
    timeline: '60-Day Scaling Blitz',
    verifiedBadge: true,
  },
  {
    id: 'luna-essentials-meta',
    title: 'Scaling US Activewear Apparel from $15k/mo to $340k Revenue',
    client: 'Luna Essentials Activewear (USA)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: '7.2x',
    heroMetricLabel: 'Blended ROAS',
    image: '/src/assets/images/ecommerce_meta_campaign_case_1793520844983.jpg',
    results: {
      spend: '$47,222',
      revenue: '$340,000',
      roas: '7.2x',
      cpa: '$16.65',
      impressions: '1.2M Reach',
    },
    challenge:
      'The client was stuck at an unprofitable 1.8x ROAS with ad fatigue across legacy single-image ads, skyrocketing CPMs in US/UK markets, and high cart abandonment.',
    solution:
      'Restructured into Advantage+ Shopping (ASC+) backed by dynamic creative testing (DCT) reels, lifestyle UGC video hooks, and high-converting collection ads with catalog retargeting.',
    keyTactics: [
      'Engineered 14 rapid UGC hook variations highlighting fabric flexibility and sweat resistance',
      'Consolidated 8 fractured ad sets into 1 unified ASC+ campaign with broad targeting',
      'Configured Meta Conversions API (CAPI) for 98% event match quality and accurate purchase tracking',
      'Implemented post-purchase upsell funnel raising Average Order Value from $78 to $120',
    ],
    timeline: '30-Day Blitz Sprint',
    verifiedBadge: true,
  },
  {
    id: 'global-ecomm-scaling',
    title: 'Q4 Global E-Commerce Blitz: 13,040 Purchases at $14.15 CPA',
    client: 'Nordic Lifestyle & Accessories (Global)',
    platform: 'Meta Ads',
    category: 'ecommerce',
    heroMetric: '6.42x',
    heroMetricLabel: 'Campaign ROAS',
    image: '/src/assets/images/meta_ads_roas_dashboard_1793520845080.jpg',
    results: {
      spend: '$28,740',
      revenue: '$184,520',
      roas: '6.42x',
      cpa: '$14.15',
      impressions: '3.8% CTR',
    },
    challenge:
      'Aggressive Q4 holiday competition led to inflated auction costs, making traditional interest-based targeting unprofitable for this accessories store.',
    solution:
      'Shifted to an algorithmic bid strategy with Cost Caps and Minimum ROAS rules, paired with localized creative angles for US, UK, and European markets.',
    keyTactics: [
      'Segmented high-intent cart abandoners with dynamic scarcity video ads',
      'Deployed automated CBO scaling with rules that bumped budget +20% on winning ad sets every 48 hours',
      'Iterated on the top 3 high-retention video hooks achieving 3.8% outbound click-through rate',
      'Delivered 13,040 verified purchases with consistent sub-$15 Cost Per Acquisition',
    ],
    timeline: 'October Scaling Run',
    verifiedBadge: true,
  },
  {
    id: 'viral-tiktok-audio-gear',
    title: 'TikTok Viral Ads: 1.2M Views into $248,125 Sales',
    client: 'PulseAudio Pro Earbuds (US / UK)',
    platform: 'TikTok Ads',
    category: 'ecommerce',
    heroMetric: '5.9x',
    heroMetricLabel: 'TikTok ROAS',
    image: '/src/assets/images/tiktok_ads_scaling_results_1793520846933.jpg',
    results: {
      spend: '$42,350',
      revenue: '$248,125',
      roas: '5.9x',
      cpa: '$28.32',
      impressions: '1.2M Impressions',
    },
    challenge:
      'Traditional polished corporate product videos flopped on TikTok with under 15% 2-second view rates and exorbitant customer acquisition costs.',
    solution:
      'Pivoted 100% to authentic UGC Spark Ads, relatable problem hooks ("Why your expensive earbuds hurt after 20 mins"), and trending native audio styles.',
    keyTactics: [
      'Partnered with 8 micro-creators on performance-based Spark Ads whitelisting',
      'Achieved a 68% average video completion rate on the leading 15-second creative',
      'Optimized TikTok Pixel events with Advanced Matching and automated daily budget reallocation',
      'Scaled daily ad spend from $300/day to $1,500/day while holding ROAS stable above 5.8x',
    ],
    timeline: 'June Campaign Sprint',
    verifiedBadge: true,
  },
  {
    id: 'high-ticket-b2b-leadgen',
    title: '850 Qualified Booked Calls at $12.40 CPL (-44% CPL)',
    client: 'Apex Capital & B2B Advisory (US & UAE)',
    platform: 'Meta Ads',
    category: 'leadgen',
    heroMetric: '$1.2M+',
    heroMetricLabel: 'Pipeline Generated',
    image: '/src/assets/images/leadgen_meta_b2b_results_1793520845265.jpg',
    results: {
      spend: '$10,540',
      revenue: '$1,200,000+ pipeline',
      roas: '11.4x (Est.)',
      cpa: '$12.40 CPL',
      leads: '850 Booked Calls',
    },
    challenge:
      'Previous agency generated junk leads that never showed up to sales discovery calls, with high CPL of $22.14 and sub-35% show-up rates.',
    solution:
      'Redesigned the entire Meta Lead Generation architecture using Interactive Instant Lead Forms with 3 custom qualification filter questions and SMS/Calendar sync.',
    keyTactics: [
      'Added high-intent friction fields: company revenue bracket and immediate timeline questions',
      'Cut cost per lead from $22.14 down to $12.40 (a massive 44% cost reduction)',
      'Integrated Calendly automated SMS reminders elevating qualified call show-up rate to 78%',
      'Targeted C-level decision-makers and founders through custom lookalikes and broad interest layering',
    ],
    timeline: '9-Month Growth Partnership',
    verifiedBadge: true,
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-pk',
    clientName: 'Bilal Chaudhry',
    role: 'Co-Founder & Head of Growth',
    company: 'Zephyr Apparel PK',
    companyType: 'Leading Pakistani D2C Brand (Lahore & Karachi)',
    quote:
      'Pakistan me e-commerce chalana asaan nahi hota COD return rates ki wajah se. Shan bhai ne hamare Meta Ads ko completely transform kia. Roman Urdu UGC creatives banaye aur WhatsApp confirmation bot lagwaya jis se hamara delivery rate 60% se 89% ho gaya aur sales Rs. 85 Lacs cross kar gayi. Best media buyer in Pakistan!',
    metricsResult: 'Rs. 85+ Lacs / Mo & 89% Delivery Rate',
    avatarSeed: 'Bilal',
  },
  {
    id: 'test-1',
    clientName: 'Hamza Tariq',
    role: 'Founder & CEO',
    company: 'Urban Threads International',
    companyType: 'D2C E-Commerce Brand (USA & PK)',
    quote:
      'Shan completely revolutionized our Meta Ads. We were hovering around 2.1x ROAS before hiring Shan\'S Digital8. Within 45 days, our blended ROAS hit 6.8x and we scaled our monthly revenue past $120k without losing margin. His creative testing strategy is pure gold.',
    metricsResult: '+224% Revenue in 45 Days',
    avatarSeed: 'Hamza',
  },
  {
    id: 'test-2',
    clientName: 'Marcus Vance',
    role: 'Growth Director',
    company: 'Veloce Tech Accessories',
    companyType: 'Shopify Plus Brand (USA)',
    quote:
      'TikTok Ads always seemed like a black hole where we burned money until Shan stepped in. He launched native Spark Ads with high-converting UGC hooks that gave us our first 5.9x ROAS campaign. He treats our ad spend as if it were his own money.',
    metricsResult: '$248k Sales in 30 Days',
    avatarSeed: 'Marcus',
  },
  {
    id: 'test-3',
    clientName: 'Sara Al-Mansoor',
    role: 'Managing Partner',
    company: 'Elevate Advisory Group',
    companyType: 'B2B Consulting (Dubai & GCC)',
    quote:
      'The quality of leads Shan generates on Meta is unmatched. We used to spend $30+ per lead with half of them being unqualified. Shan dropped our CPL to $12.40 and filled our sales calendar with high-ticket prospects. Outstanding professional.',
    metricsResult: '850+ Booked Qualified Calls',
    avatarSeed: 'Sara',
  },
];

export const SERVICES = [
  {
    number: '01',
    title: 'Meta Ads Scaling (Facebook & Instagram)',
    tagline: 'Advantage+ & Local/Global Algorithmic Engine',
    description:
      'Turn Facebook & Instagram into predictable revenue engines. Whether scaling in Pakistan with COD confirmation and local courier integrations or international US/UK markets with ASC+ and high-AOV funnels, we maximize profitable returns.',
    features: [
      'Advantage+ Shopping Campaigns (ASC+) Mastery',
      'Pakistan COD Delivery Optimization & WhatsApp Order Bot',
      'Server-Side Meta Conversions API (CAPI) & Pixel Setup',
      'CBO & ABO Scaling Architectures with Cost Caps',
    ],
    platforms: ['Meta', 'Instagram', 'Shopify', 'PostEx/Trax'],
  },
  {
    number: '02',
    title: 'TikTok Ads & Viral Spark Ads',
    tagline: 'High-Retention UGC & FYP Dominance',
    description:
      'Capture Gen Z and Millennial purchasing power with native TikTok creative strategies. We build scroll-stopping Spark Ads, UGC creator funnels, and algorithmic scaling setups tailored for rapid impulse buys across US, UK, and Pakistan.',
    features: [
      'High-Converting TikTok Spark Ads & Whitelisting',
      'Hook Rate & Hold Rate Creative Iteration',
      'TikTok Shop Integration & Catalog Synchronization',
      'Micro-Budget Testing to High-Velocity Scaling',
    ],
    platforms: ['TikTok', 'CapCut', 'TikTok Shop'],
  },
  {
    number: '03',
    title: 'Creative Strategy & UGC Production Pipeline',
    tagline: 'Ads Engineered for the First 3 Seconds',
    description:
      'Creative is the modern targeting. We script, storyboard, and iterate on high-converting video hooks, unboxings, problem/solution demos, and direct-response graphics in English, Urdu, and Roman Urdu that drastically lower CPA.',
    features: [
      'Direct-Response UGC Scripting (English & Urdu/Roman Urdu)',
      'Scroll-Stopping 3-Second Hook Testing Matrix',
      'Motion Graphics, Static Carousels & Dynamic Assets',
      'Iterative Creative Refresh to Beat Ad Fatigue',
    ],
    platforms: ['Reels', 'TikTok', 'Stories'],
  },
  {
    number: '04',
    title: 'High-Ticket B2B & Lead Generation Funnels',
    tagline: 'Qualified Pipeline, Not Unresponsive Clicks',
    description:
      'Fill your sales calendar with ready-to-buy decision-makers. We build interactive Meta Instant Forms, multi-step qualification filters, and automated calendar booking sequences that convert cold traffic into closed deals.',
    features: [
      'High-Intent Friction Filtering Questions',
      'Instant Webhook Sync with CRM & Calendly',
      'Automated SMS & WhatsApp Nurture Integration',
      'Lookalike Modeling from High-LTV Customer Data',
    ],
    platforms: ['Meta Leads', 'Zapier', 'WhatsApp API'],
  },
];

export const FAQS = [
  {
    question: 'Can you work with both Pakistani local brands and international clients?',
    answer:
      'Yes, absolutely! We actively manage advertising campaigns for both local Pakistani businesses (Shopify PK, Cash on Delivery, courier return reduction, WhatsApp bots) and international brands across the USA, UK, UAE/Gulf, Canada, and Europe. Our strategies adapt seamlessly to the local market mechanics.',
  },
  {
    question: 'How do you handle Cash on Delivery (COD) returns in Pakistan?',
    answer:
      'In Pakistan, COD return rates (RTO) are the biggest margin killer. We implement automated 1-click WhatsApp order confirmation bots, verify phone numbers and addresses before booking, and connect courier APIs (PostEx, Trax, Leopards) for automated customer re-attempts. This routinely lifts delivery rates from 60% up to 88%–90%.',
  },
  {
    question: 'What monthly ad spend do I need to work with Shan\'S Digital8?',
    answer:
      'For Pakistani brands, budgets start from Rs. 50,000/month for initial testing up to Rs. 25–50+ Lacs/month for high-growth scale. For international clients, we work with spend levels from $1,000 to $100,000+/month. Check our interactive Budget Calculator to test projections for your exact currency!',
  },
  {
    question: 'How fast can Shan launch our Meta or TikTok ad campaigns?',
    answer:
      'Once onboarding is complete and tracking/access is verified, initial creative testing campaigns launch within 3 to 5 business days. The first 7 days focus on validating winning creative hooks and establishing baseline CPA, after which we initiate our scaling framework.',
  },
  {
    question: 'How do you handle iOS 14.5+ tracking and attribution issues?',
    answer:
      'We implement robust server-side Meta Conversions API (CAPI) and TikTok Advanced Matching. This bypasses ad-blockers and browser cookie restrictions, recovering 20-35% of lost attribution data and ensuring Facebook and TikTok algorithms optimize on real purchase signals.',
  },
];
