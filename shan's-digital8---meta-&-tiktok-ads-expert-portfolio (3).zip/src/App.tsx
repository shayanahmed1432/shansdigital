/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CaseStudyModal from './components/CaseStudyModal';
import AuditBookingModal from './components/AuditBookingModal';
import SevenDayTrialModal from './components/SevenDayTrialModal';
import MobileBottomNav from './components/MobileBottomNav';
import FloatingActions from './components/FloatingActions';
import ShansAIChat from './components/ShansAIChat';
import WhatsAppButton from './components/WhatsAppButton';
import PageLoadingBar from './components/PageLoadingBar';

import HomePage from './pages/HomePage';
import ResultsPage from './pages/ResultsPage';
import ServicesPage from './pages/ServicesPage';
import CalculatorPage from './pages/CalculatorPage';
import CreativeLabPage from './pages/CreativeLabPage';
import AboutPage from './pages/AboutPage';
import MetaAdsPage from './pages/MetaAdsPage';
import SocialMediaMarketingPage from './pages/SocialMediaMarketingPage';
import TikTokAdsPage from './pages/TikTokAdsPage';
import CreativeServicesPage from './pages/CreativeServicesPage';
import EcommerceManagementPage from './pages/EcommerceManagementPage';
import OffersPage from './pages/OffersPage';
import ContactPage from './pages/ContactPage';

import { CaseStudy, PageRoute } from './types';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageRoute>('home');
  const [isNavigating, setIsNavigating] = useState<boolean>(false);
  const [isDark, setIsDark] = useState<boolean>(true); // Default to agency dark theme #080808
  const [isAuditModalOpen, setIsAuditModalOpen] = useState<boolean>(false);
  const [isTrialModalOpen, setIsTrialModalOpen] = useState<boolean>(false);
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudy | null>(null);
  const [prefilledSpend, setPrefilledSpend] = useState<number | null>(null);

  // Sync theme with HTML documentElement
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Page routing handler with realistic loading indicator & smooth transition
  const handleNavigate = (page: PageRoute) => {
    if (page === currentPage) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setIsNavigating(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // 250ms realistic page shift transition
    setTimeout(() => {
      setCurrentPage(page);
      setIsNavigating(false);
    }, 250);
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  const handleOpenAudit = (spend?: number) => {
    if (spend) {
      setPrefilledSpend(spend);
    } else {
      setPrefilledSpend(null);
    }
    setIsAuditModalOpen(true);
  };

  const handleCloseAudit = () => {
    setIsAuditModalOpen(false);
  };

  const handleOpenTrial = () => {
    setIsTrialModalOpen(true);
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white dark:bg-[#080808] text-neutral-900 dark:text-neutral-100 transition-colors duration-200 flex flex-col justify-between selection:bg-orange-500 selection:text-white">
      {/* Top Page Progress Loading Bar */}
      <PageLoadingBar isNavigating={isNavigating} />

      {/* Top Bar Navigation with dedicated page routing & services dropdown */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenAudit={() => handleOpenAudit()}
        isDark={isDark}
        toggleTheme={toggleTheme}
      />

      {/* Main Routed Page Content with safe padding for mobile bottom bar */}
      <main
        className={`flex-1 w-full max-w-full overflow-x-hidden pb-28 lg:pb-0 transition-opacity duration-200 ${
          isNavigating ? 'opacity-60' : 'opacity-100'
        }`}
      >
        {currentPage === 'home' && (
          <HomePage
            onOpenAudit={() => handleOpenAudit()}
            onOpenTrial={handleOpenTrial}
            onSelectCaseStudy={(study) => setSelectedCaseStudy(study)}
            onOpenAuditWithSpend={(spend) => handleOpenAudit(spend)}
            onNavigate={handleNavigate}
            isDark={isDark}
          />
        )}

        {currentPage === 'results' && (
          <ResultsPage
            onSelectCaseStudy={(study) => setSelectedCaseStudy(study)}
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'meta-ads' && (
          <MetaAdsPage
            onOpenAudit={() => handleOpenAudit()}
            onOpenTrial={handleOpenTrial}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'social-media' && (
          <SocialMediaMarketingPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'tiktok-ads' && (
          <TikTokAdsPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'creative-services' && (
          <CreativeServicesPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'ecommerce-management' && (
          <EcommerceManagementPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'offers' && (
          <OffersPage
            onOpenAudit={() => handleOpenAudit()}
            onOpenTrial={handleOpenTrial}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            onOpenAudit={() => handleOpenAudit()}
            onOpenTrial={handleOpenTrial}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'calculator' && (
          <CalculatorPage
            onOpenAuditWithSpend={(spend) => handleOpenAudit(spend)}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'creative-lab' && (
          <CreativeLabPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'agency' && (
          <AboutPage
            onOpenAudit={() => handleOpenAudit()}
            onNavigate={handleNavigate}
            isDark={isDark}
          />
        )}
      </main>

      {/* Global Agency Footer */}
      <Footer
        onOpenAudit={() => handleOpenAudit()}
        onNavigate={handleNavigate}
      />

      {/* Premium Mobile Bottom Navigation Bar (app-like, fixed, safe-area inset compliant) */}
      <MobileBottomNav
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenAudit={() => handleOpenAudit()}
      />

      {/* Modals & Interactive Overlays */}
      <CaseStudyModal
        study={selectedCaseStudy}
        onClose={() => setSelectedCaseStudy(null)}
        onOpenAudit={() => handleOpenAudit()}
      />

      <AuditBookingModal
        isOpen={isAuditModalOpen}
        onClose={handleCloseAudit}
        prefilledSpend={prefilledSpend}
      />

      <SevenDayTrialModal
        isOpen={isTrialModalOpen}
        onClose={() => setIsTrialModalOpen(false)}
      />

      {/* Shan's AI Assistant Chat Agent & Free Creative Audit Engine */}
      <ShansAIChat
        onOpenAudit={() => handleOpenAudit()}
        onOpenTrial={() => setIsTrialModalOpen(true)}
        isDark={isDark}
      />

      {/* Official High-Conversion WhatsApp Floating Button */}
      <WhatsAppButton />

      {/* Scroll to Top floating utility */}
      <FloatingActions />
    </div>
  );
}
