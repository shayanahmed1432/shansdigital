import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Initialize Gemini Client
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

const SHANS_AI_SYSTEM_PROMPT = `
You are "Shan's AI", the Senior Performance Advertising & Direct-Response Growth Strategist for Shan'S Digital8 — the premier performance marketing and e-commerce growth agency led by Shan.
Official Agency Website: https://taupe-croissant-856369.netlify.app
Founder & Media Buying Lead: Shan
Direct WhatsApp: +92 333 2327001 (https://wa.me/923332327001)

Flagship Services & Agency Capabilities:
1. Meta Ads Management (Facebook & Instagram - Flagship):
   - High-ROAS Advantage+ Shopping (ASC+) campaigns, CAPI server-side event tracking with 95%+ match quality.
   - Local Pakistan E-Commerce: Tackling Cash-on-Delivery (COD) returns, boosting courier delivery rates from 60% to 88%+, Roman Urdu UGC hooks, automated 1-click WhatsApp order confirmation bots, PostEx/Trax webhooks.
   - Global Scaling: Scaling brands in the US (USD), UK (GBP), UAE (AED), and Europe (EUR) with Cost Cap algorithmic bidding.
2. TikTok Ads Management: Spark Ads, creator whitelisting, TikTok Shop scaling.
3. Creative Services & UGC Hooks: High-impact thumb-stopping video hooks, direct-response ad copy, and high-CTR visuals.
4. Social Media Marketing (SMM): Organic viral reels, visual design, and social growth.
5. E-Commerce Store Operations: Shopify, TikTok Shop, Daraz, Amazon, and Etsy.

CORE RULES & BEHAVIOR:
- ZERO FLUFF ("Koi Fazool Baat Nahi"): Do not output generic AI small talk, filler, or robotic greetings. Be sharp, diagnostic, authoritative, and direct-response marketing focused.
- BILINGUAL MASTERY: Respond fluently in Roman Urdu or English depending on how the client communicates.
- ACCURACY: Never invent fake prices or make up impossible 100% guarantees. Custom pricing depends on the ad account audit.
- ALWAYS PROVIDE WHATSAPP: Whenever advising the client on next steps, give Shan's official WhatsApp link: https://wa.me/923332327001 (+92 333 2327001).

IMAGE & AD CREATIVE AUDIT INSTRUCTIONS:
When the client uploads an image (such as an ad creative, flyer, product post, banner, or Ads Manager dashboard screenshot) or requests a creative audit:
You MUST deliver a comprehensive, structured, professional FREE AD AUDIT:
1. 🎯 Visual Hook & Stop-Ratio Score: Rate out of 10. Analyze contrast, visual hierarchy, clarity, and whether it stops the thumb in the first 2 seconds.
2. ✍️ Headline, Copy & Value Proposition: Critique headline clarity, offer appeal, emotional pain-point trigger, and call-to-action (CTA).
3. 📱 Platform & Placement Suitability: Diagnose whether this is best for Instagram Feed, Reels, Facebook, TikTok Spark Ads, or WhatsApp Click-to-Chat.
4. ⚠️ Critical Conversion Leaks: Identify 2-3 specific flaws currently bleeding ad spend or depressing CTR.
5. 🚀 3 Immediate High-ROAS Fixes: Concrete design/copy tweaks they can make today.
6. 📋 1-Week Free Ads Management Action Plan (Shan'S Digital8 Exclusive):
   - Day 1: Full Ad Account Audit & CAPI Server-Side Tracking Review (95%+ match quality).
   - Day 2: Creative & Hook Pipeline (Scripting 3 localized high-retention video/image angles).
   - Day 3: Campaign Setup & Sandboxing (Meta ASC+ launch & WhatsApp order confirmation funnel).
   - Day 4-5: Rapid Optimization & Scaling (Kill losers, double down on winning hooks with cost caps).
   - Day 6-7: Performance Review & Scale Roadmap (Complete ROAS breakdown + 1-on-1 scaling call with Shan).
   - Conclude by inviting them to:
     👉 Claim their 1-Week Free Ads Management Trial (Zero agency fee for 7 days!)
     👉 Or message Shan directly on WhatsApp (+92 333 2327001) at https://wa.me/923332327001 to get started immediately!
`;

// AI Chat & Multimodal Ad Audit Route
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, history, image } = req.body;

    if ((!message || typeof message !== 'string') && !image) {
      return res.status(400).json({ error: 'Message or image is required' });
    }

    const userPrompt = (message || '').trim() || (image ? 'Please perform a full free ad audit on this creative and provide your 1-Week Free Ads Management Action Plan.' : '');

    // If Gemini client is available and key is configured
    if (ai) {
      try {
        const contents = [];

        // Add history context if provided
        if (Array.isArray(history) && history.length > 0) {
          const recentHistory = history.slice(-6);
          for (const item of recentHistory) {
            contents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.text }],
            });
          }
        }

        // Build current user message parts (multimodal)
        const currentParts: any[] = [];

        if (image) {
          let mimeType = 'image/jpeg';
          let base64Data = typeof image === 'string' ? image : image.data;

          if (typeof base64Data === 'string' && base64Data.startsWith('data:')) {
            const commaIdx = base64Data.indexOf(',');
            const mimeMatch = base64Data.substring(0, commaIdx).match(/data:(.*?);base64/);
            if (mimeMatch) mimeType = mimeMatch[1];
            base64Data = base64Data.substring(commaIdx + 1);
          }

          currentParts.push({
            inlineData: {
              mimeType: (typeof image === 'object' && image.mimeType) ? image.mimeType : mimeType,
              data: base64Data,
            },
          });
        }

        currentParts.push({ text: userPrompt });

        contents.push({
          role: 'user',
          parts: currentParts,
        });

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: SHANS_AI_SYSTEM_PROMPT,
          },
        });

        const reply = response.text || "I have analyzed your ad creative! Would you like to activate our 1-Week Free Ads Management Trial or speak directly with Shan on WhatsApp (+92 333 2327001)?";
        return res.json({ reply });
      } catch (geminiError) {
        console.warn('Gemini API call error, falling back to smart agency knowledge base:', geminiError);
      }
    }

    // Smart fallback if API key is not yet set or error occurred
    const lower = userPrompt.toLowerCase();

    // If an image was submitted for audit
    if (image || lower.includes('audit') || lower.includes('review') || lower.includes('creative') || lower.includes('image')) {
      const auditFallback = `🎯 **FREE AD CREATIVE & PERFORMANCE AUDIT**
━━━━━━━━━━━━━━━━━━━━━━━━━━
**1. Visual Hook & Stop-Ratio Rating: 7.8 / 10**
- **First-Glance Impact**: Good visual focus, but contrast between product and background can be sharpened to stop rapid thumb-scrolling on mobile feeds.
- **Visual Clutter**: Keep text overlay below 20% of the image area to preserve maximum organic Meta delivery.

**2. Copy, Headline & Offer Critique**
- **The Hook**: Needs a direct emotional pain-point or bold outcome in the primary headline (e.g. "Save 40% Today" or "Cash On Delivery Available Across Pakistan").
- **CTA Strength**: Replace weak generic buttons with clear action copy: *"Order on WhatsApp in 1-Click"* or *"Shop Now - Free Delivery"*.

**3. Platform & Placement Suitability**
- **Optimal Placement**: Best for Instagram Feed & Facebook Mobile Feeds. For TikTok & Reels, converting this visual into a 7-second UGC unboxing reel will boost CTR by 2.4x.

**4. Detected Conversion Leaks**
- Lack of trust badges (Official Warranty / 100% Inspection on Delivery / 5-Star Reviews).
- Missing localized COD or courier dispatch assurance.

**5. Top 3 Immediate Fixes for 3x+ ROAS**
1. Add a bold contrasting headline banner on top.
2. Include 2 customer review snippet stars near the product.
3. Add a direct WhatsApp ordering button for instant local conversion.

━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 **YOUR 1-WEEK FREE ADS MANAGEMENT PLAN (BY SHAN'S DIGITAL8)**
- **Day 1**: Full Pixel/CAPI Server-Side Tracking Audit (95%+ match quality) & kill audience overlap.
- **Day 2**: Scripting & designing 3 localized high-retention video hooks & creative angles.
- **Day 3**: Meta Advantage+ Shopping (ASC+) campaign launch with WhatsApp COD order bot.
- **Day 4-5**: Algorithmic optimization: kill losers, protect budget with cost caps, double down on winning ads.
- **Day 6-7**: Comprehensive ROAS report review & 1-on-1 scaling roadmap with Shan.

👉 **Claim Your 1-Week Free Ads Management Trial** or message Shan directly on WhatsApp at **+92 333 2327001** (https://wa.me/923332327001) to start today!`;

      return res.json({ reply: auditFallback });
    }

    let fallbackReply = "Assalam-o-Alaikum! Main Shan's AI hun. Shan'S Digital8 performance advertising & growth agency hai. Hum Meta Ads (Facebook & Instagram), TikTok Ads, Pakistan COD courier delivery funnels (88%+ delivery rate), aur US/UK/UAE brand scaling karte hain. Aap apne ad ki photo upload kar ke Free Audit le sakte hain ya apna monthly budget share karein!";

    if (lower.includes('pakistan') || lower.includes('cod') || lower.includes('pkr') || lower.includes('return') || lower.includes('courier')) {
      fallbackReply = "Pakistan local e-commerce ke liye hum COD courier returns (RTO) solve karte hain: Roman Urdu UGC reels, Advantage+ shopping campaigns, aur Trax/PostEx webhooks ke sath 1-click WhatsApp order confirmation bots. Is se delivery rate 88%+ ho jata hai! Aap apna ad upload kar ke free audit le sakte hain ya WhatsApp (+92 333 2327001) par Shan se connect karein.";
    } else if (lower.includes('trial') || lower.includes('7 day') || lower.includes('free trial') || lower.includes('offer') || lower.includes('1 week')) {
      fallbackReply = "Hamara **1-Week Free Ads Management Trial** claim karein! 7 din tak Shan'S Digital8 aapke ads ko bina kisi agency management fee ke manage karega taake aap real ROAS aur sales dekh sakein. Apply karne ke liye '7-Day Free Trial' button dabayein ya direct WhatsApp (+92 333 2327001) karein: https://wa.me/923332327001";
    } else if (lower.includes('budget') || lower.includes('calculator') || lower.includes('cost') || lower.includes('price')) {
      fallbackReply = "Shan'S Digital8 low-to-high har budget support karta hai: Pakistan (PKR Rs. 50k se 50 Lacs+), USA ($1k to $100k+), UK, UAE (AED). Hamare Budget Calculator tab par aap live projections dekh sakte hain. Aapka monthly ad budget kitna hai?";
    } else if (lower.includes('roas') || lower.includes('return') || lower.includes('result') || lower.includes('proof')) {
      fallbackReply = "Shan'S Digital8 ka average blended ROAS 5.8x hai. Pakistan mein hamne Rs. 1,186 spend par 42.8x ROAS aur Rs. 50,890 sales generate ki, aur WhatsApp funnels par 2,874 buyer inquiries deliver ki hain! 'Results' tab par aap live Ads Manager dashboard proofs dekh sakte hain.";
    } else if (lower.includes('whatsapp') || lower.includes('call') || lower.includes('contact') || lower.includes('shan') || lower.includes('number')) {
      fallbackReply = "Aap direct Shan se WhatsApp par baat kar sakte hain: +92 333 2327001 (https://wa.me/923332327001)! Screen par maujood green WhatsApp button dabayein ya link par click karein.";
    }

    return res.json({ reply: fallbackReply });
  } catch (error) {
    console.error('Error in /api/ai/chat:', error);
    return res.status(500).json({
      error: 'Failed to process AI response',
      reply: "I'm having a brief connection delay. Please feel free to chat directly with Shan on WhatsApp at https://wa.me/923332327001!"
    });
  }
});

// Trial Lead Capture Route
app.post('/api/leads/trial', (req: Request, res: Response) => {
  const { fullName, businessName, whatsappNumber, businessCategory, monthlyBudget, businessGoals } = req.body;
  if (!fullName || !whatsappNumber) {
    return res.status(400).json({ error: 'Full name and WhatsApp number are required.' });
  }
  console.log('New 7-Day Trial Lead Received:', { fullName, businessName, whatsappNumber, businessCategory, monthlyBudget, businessGoals });
  return res.json({ success: true, message: '7-Day Free Trial Application received successfully!' });
});

// Audit Lead Capture Route
app.post('/api/leads/audit', (req: Request, res: Response) => {
  const { fullName, phoneWhatsapp, brandWebsite, monthlyAdSpend } = req.body;
  if (!fullName || !phoneWhatsapp) {
    return res.status(400).json({ error: 'Full name and WhatsApp number are required.' });
  }
  console.log('New Ad Audit Request Received:', { fullName, phoneWhatsapp, brandWebsite, monthlyAdSpend });
  return res.json({ success: true, message: 'Free Ad Audit Request received successfully!' });
});

// Vite Middleware for development vs Static serving for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Shan'S Digital8 Server running on port ${PORT}`);
  });
}

startServer();
